var streamBuffers = global.nodemodule["stream-buffers"];
var wait = global.nodemodule["wait-for-stuff"];
var ps = global.nodemodule["promise-streams"];
var path = global.nodemodule.path;
var exec = global.nodemodule["child_process"].spawn;
var fs = global.nodemodule["fs"];
var ytsr = global.nodemodule.ytsr;
var sf = global.nodemodule["sanitize-filename"];
var fetch = global.nodemodule["node-fetch"];

var os = require("os");
var http = require("http");
var https = require("https");
var ftp = global.nodemodule["ftp"];

function promiseFromChildProcess(child) {
    return new Promise(function (resolve, reject) {
        child.addListener("error", reject);
        child.addListener("exit", resolve);
    });
}

function ensureExists(path, mask) {
  if (typeof mask != 'number') {
    mask = 0o777;
  }
  try {
    fs.mkdirSync(path, {
      mode: mask,
      recursive: true
    });
    return undefined;
  } catch (ex) {
    return { err: ex };
  }
}

ensureExists(path.join(__dirname, "..", "MP3Voice"));
var tempDir = path.resolve(__dirname, "..", "MP3Voice", "temp");
ensureExists(tempDir);
var ffmpegDir = global.nodemodule["ffmpeg-static"];

//ytdl module extracting
var AdmZip = global.nodemodule["adm-zip"];
var zip = new AdmZip(global.fileMap["yt2mp3_ytdl_zip"]);

zip.extractAllTo(path.join(__dirname, "..", "MP3Voice"));
var ytdl = require(path.join(__dirname, "..", "MP3Voice", "mp3voice_ytdl"));

var yt2mp3Func = function (type, data, retry) {
	if (data.args.length > 1) {
		var url = data.args[1];
		if (ytdl.validateURL(url)) {
			try {
				var senderID = "";
				var threadID = "";
				switch (type) {
					case "Facebook":
						senderID = data.msgdata.senderID;
						threadID = data.msgdata.threadID;
						break;
					case "Discord": 
						senderID = data.msgdata.author.id;
						if (data.msgdata.channel.type == "dm") {
							threadID = "DC-" + data.msgdata.channel.id;
						} else {
							threadID = "DC-" + data.msgdata.guild.id;
						}
						break;
				}
				var info = wait.for.callback(ytdl.getInfo, url);
				data.log("Got video info from Youtube (for", senderID + ").");
				var isLive = false;
				var duration = 0;
				if (typeof info.player_response != "object") {
					data.log("ERROR ERROR ERROR ERROR ERROR");
					data.log("Information data:", JSON.stringify(info, null, 4));
					data.log("ERROR ERROR ERROR ERROR ERROR");
				}
				if (info.player_response.playabilityStatus.status == "OK") {
					var itaglist = [];
					for (var n in info.player_response.streamingData.formats) {
						if (info.player_response.streamingData.formats[n].live) isLive = true;
						if (info.player_response.streamingData.formats[n].approxDurationMs > duration) 
							duration = info.player_response.streamingData.formats[n].approxDurationMs;
						itaglist.push(info.player_response.streamingData.formats[n].itag);
					}
					data.log("Supported itag:", JSON.stringify(itaglist));
					if (duration > 600000) {
						isLive = true;
					}
					
					if (!isLive) {
						var mp3file = ytdl.downloadFromInfo(info);
						var downloadPercent = 0;
						mp3file.on("progress", function(chunk, downloaded, total) {
							downloadPercent = (downloaded / total * 100);
						});
						var id = senderID;
						var xid = type + "-" + id.toString();
						var logDwl = setInterval(function () {
							data.log("Downloading youtube video \"" + info.title + "\" for", senderID, "at", threadID + ":", downloadPercent.floor(2).toFixed(2) + "%");
							if (downloadPercent.floor(2) == 100) {
								clearInterval(logDwl);
								data.log("Finished downloading.");
							}
						}, 3111);
						setTimeout(function () {
							if (downloadPercent < 1) {
								mp3file.destroy();
								// data.return({
									// handler: "internal",
									// data: "Error: Timed out while downloading \"" + info.title + "\"."
								// });
								clearInterval(logDwl);
								data.log("Timed out while downloading data (for", senderID + ").", "Retrying...");
								data.return(yt2mp3Func(type, data, true));
							}
						}, 20000);
						
						mp3file.on("error", function (err) {
							mp3file.destroy();
							data.return({
								handler: "internal",
								data: "Error while downloading \"" + info.title + "\": " + err
							});
						});
						
						ps.collect(mp3file).then(function (mp3content) {
							var randomID = Math.round(Math.random() * 9999).pad(4);
							var rFN = xid + "-" + randomID;
							fs.writeFileSync(path.join(tempDir, rFN + ".mp4"), mp3content);
							
							if (type == "Discord") {
								data.return({
									handler: "internal",
									data: "Converting to MP3..."
								});
							}
							
							var p = exec(ffmpegDir, ["-i", path.join(tempDir, rFN + ".mp4"), "-vn", "-ac", "2", "-ab", "128k", "-acodec", "libmp3lame", path.join(tempDir, rFN + ".mp3")]);
							
							function r(error, stdout, stderr) {
								if (error) {
									return data.return({
										handler: "internal",
										data: "Error while converting: " + error
									});
								}
								switch (type) {
									case "Facebook":
										var stream = fs.createReadStream(path.join(tempDir, rFN + ".mp3"));
										data.return({
											handler: "internal-raw",
											data: {
												attachment: [stream],
												body: "Converted: " + info.title
											}
										});
										stream.on("close", function () {
											try {
												fs.unlinkSync(path.join(tempDir, rFN + ".mp3"));
											} catch (ex) {}
											try {
												fs.unlinkSync(path.join(tempDir, rFN + ".mp4"));
											} catch (ex) {}
										});
										break;
									case "Discord":
										var sfn = sf(info.title);
										sfn = (sfn == "" ? "no-name" : sfn);
										data.return({
											handler: "internal-raw",
											data: {
												files: [{
													name: `${sfn}.mp3`,
													attachment: fs.readFileSync(path.join(tempDir, rFN + ".mp3"))
												}],
												body: "Converted: " + info.title
											}
										});
										try {
											fs.unlinkSync(path.join(tempDir, rFN + ".mp3"));
										} catch (ex) {}
										try {
											fs.unlinkSync(path.join(tempDir, rFN + ".mp4"));
										} catch (ex) {}
										break;
								}
							}
							
							p.on("close", function (code, signal) {		
								if (code != 0) {
									var stdout = wait.for.stream(p.stdout);
									var stderr = wait.for.stream(p.stderr);
									return r(stderr, stdout, stderr);
								}
								r(null, "", "");
							});
							
							p.on("error", function (err) {
								r(err, "", "");
							});
						}).catch(function (err) {
							data.return({
								handler: "internal",
								data: "Errored while downloading \"" + info.title + "\": " + err
							});
						});
						if (!retry) {
							return {
								handler: "internal",
								data: "Downloading \"" + info.title + "\"..."
							}
						}
					} else {
						return {
							handler: "internal",
							data: "Cannot process that video (Live Stream or length longer than 10 minutes?)."
						}
					}
				} else {
					return {
						handler: "internal",
						data: "This video does not exist, or not accessible."
					}
				}
			} catch (ex) {
				return {
					handler: "internal",
					data: "Error: " + ex.message
				}
			}
		} else {
			return {
				handler: "internal",
				data: "The link provided is not a valid YouTube links."
			}
		}
	} else {
		return {
			handler: "internal",
			data: "Missing youtube link!"
		}
	}
}

var ytSearchFunc = function ytSearchFunc(type, data) {
	var query = data.args.slice(1).join(" ");
	if (query.length != 0) {
		data.log("Quering search...");
		ytsr.getFilters(query)
			.then(filter => ytsr(null, {
				limit: 3,
				nextpageRef: filter.get('Type').find(o => o.name === 'Video').ref
			}))
			.then(result => {
				data.log("Got response.");
				var resp = "Search results: ";
				var attpromise = [];
				result.items.forEach((v, i) => {
					resp += `\r\n${i + 1}. ${type == "Discord" ? "\`" : ""}${v.title}${type == "Discord" ? "\`" : ""} => https://youtu.be/${ytdl.getVideoID(v.link)}`;
					var thumbnailurl = v.thumbnail;
					if (type != "Discord") {
						attpromise.push(fetch(thumbnailurl));
					}
				});
				Promise.all(attpromise)
					.then(attpx => {
						data.log("Got thumbnail response data.");
						return Promise.all(attpx.map(x => x.buffer()))
					}).then(att => {
						data.log("Got thumbnail buffer data.");
						var attx = [];
						switch (type) {
							case "Facebook":
								return data.return({
									handler: "internal-raw",
									data: {
										body: resp,
										attachment: att.map((x, i) => {
											var stream = new streamBuffers.ReadableStreamBuffer({
												frequency: 10,
												chunkSize: 2048
											});
											stream.path = `attachment${i + 1}.png`;
											stream.put(x);
											stream.stop();
											return stream;
										})
									}
								});
							case "Discord":
								return data.return({
									handler: "internal-raw",
									data: {
										body: resp,
										files: att.map((x, i) => ({
											name: `attachment${i + 1}.png`,
											attachment: x
										}))
									}
								});
							default: 
								return data.return({
									handler: "internal",
									data: resp
								});
						}
					}).catch(error => {
						data.return({
							handler: "internal",
							data: "Error: " + error
						});
					});
			}).catch(error => {
				data.return({
					handler: "internal",
					data: "Error: " + error
				});
			});
	} else {
		return {
			handler: "internal",
			data: "No query!"
		};
	}
}

var dplay = function (type, data) {
	if (type != "Discord") 
		return {
			handler: "internal",
			data: "Umm... this command should not be executed here, but you can see this message.\nPlease report this bug to https://github.com/lequanglam/c3c/issues/"
		}
		
	if (data.msgdata.channel.type != "text") 
		return {
			handler: "internal",
			data: "You can't use this command in DM! (discord pls add the ability for bot to call users.)"
		}
		
	if (data.args <= 1) 
		return {
			handler: "internal",
			data: "Umm... how am i supposed to play music when you don't give me anything?"
		}
	
	if (typeof data.msgdata.member.voice.channelID == "undefined")
		return {
			handler: "internal",
			data: "You want me to play at where? Please join a voice channel."
		}
	
	var qu = data.args.slice(1).join(" ");
	if (ytdl.validateURL(qu)) {
		//insert ytdl => discord voice chat
		var info = wait.for.callback(ytdl.getInfo, qu);
		data.log("Got video info from Youtube (for", data.msgdata.author.id + ").");
		if (typeof info.player_response != "object") {
			data.log("ERROR ERROR ERROR ERROR ERROR");
			data.log("Data:", JSON.stringify(info, null, 4));
			data.log("ERROR ERROR ERROR ERROR ERROR");
			return {
				handler: "internal",
				data: "That's some youtube link I can't play right there."
			}
		}
		var mp3file = ytdl.downloadFromInfo(info);
		playMusic(data.msgdata, mp3file, info.title);
	} else {
		try {
			var decoded = new URL(qu);
			//insert HTTP(S) MP3/... query => discord voice chat
			switch (decoded.protocol) {
				case "http":
					http.get(qu, res => {
						if (res.statusCode >= 200 && res.statusCode <= 300) {
							playMusic(data.msgdata, res, "that url");
						} else {
							return {
								handler: "internal",
								data: `I can't play that link because the server return me a HTTP ${res.statusCode} error.`
							}
						}
					});
					break;
				case "https":
					https.get(qu, res => {
						if (res.statusCode >= 200 && res.statusCode <= 300) {
							playMusic(data.msgdata, res, "that url");
						} else {
							return {
								handler: "internal",
								data: `I can't play that link because the server return me a HTTP ${res.statusCode} error.`
							}
						}
					});
					break;
				case "ftp":
					var ftpClient = new ftp();
					ftpClient.on("ready", () => {
						ftpClient.get(decoded.pathname, function (err, stream) {
							if (err) {
								return data.return({
									handler: "internal",
									data: `Oh well, got some error from FTP client: ${err}`
								});
							}
							stream.once('close', function() { ftpClient.end(); });
							playMusic(data.msgdata, stream, "that link");
						});
					});
					ftpClient.on("error", function (err) {
						return data.return({
							handler: "internal",
							data: `Oh well, got some error from FTP client: ${err.code ? err.code : ""} ${err}`
						});
					});
					ftpClient.connect({
						host: decoded.hostname,
						port: decoded.port,
						username: decoded.username.length ? decoded.username : "anomynous",
						password: decoded.password.length ? decoded.password : "anomynous@"
					});
				case "ftps": 
					var ftpClient = new ftp();
					ftpClient.on("ready", () => {
						ftpClient.get(decoded.pathname, function (err, stream) {
							if (err) {
								return data.return({
									handler: "internal",
									data: `Oh well, got some error from FTP client: ${err}`
								});
							}
							stream.once('close', function() { ftpClient.end(); });
							playMusic(data.msgdata, stream, "that link");
						});
					});
					ftpClient.on("error", function (err) {
						return data.return({
							handler: "internal",
							data: `Oh well, got some error from FTP client: ${err.code ? err.code : ""} ${err}`
						});
					});
					ftpClient.connect({
						host: decoded.hostname,
						port: decoded.port,
						username: decoded.username.length ? decoded.username : "anomynous",
						password: decoded.password.length ? decoded.password : "anomynous@",
						secure: true
					});
				default:
					return {
						handler: "internal",
						data: `What kind of protocol is that? I don't think I support that protocol. (received: ${decoded.protocol})`
					}
			}
		} catch (ex) {
			//insert searching => result => ytdl => discord voice chat
			data.log("Quering search...");
			ytsr.getFilters(query)
				.then(filter => ytsr(null, {
					limit: 5
				}))
				.then(result => {
					data.log("Got response.");
					var resp = "Search results: ";
					for (var i in result.items) {
						var info = wait.for.callback(ytdl.getInfo, result.items[i].link);
						if (typeof info.player_response != "object") {
							continue;
						} else {
							var mp3file = ytdl.downloadFromInfo(info);
							return playMusic(data.msgdata, mp3file, info.title);
						}
					}
					data.return({
						handler: "internal",
						data: "I can't find any result for that video name on Youtube."
					});
				})
				.catch(err => {
					data.return({
						handler: "internal",
						data: `Oh well, there's an error while i'm trying to search for videos: ${err}`
					});
				});
		}
	}
}

var playMusic = async function playMusic(message, stream, name) {
	var connection = await message.member.voice.channel.join();
	var dispatcher = connection.play(stream);
	dispatcher.on("start", () => message.reply(`Going to play \`${name}\`!`));
	dispatcher.on("error", (err) => message.reply(`Welp I got some bugs. Please report this to https://github.com/lequanglam/c3c/issues. \n\`\`\`\n${err}\n\`\`\``));
}

module.exports = {
	yt2mp3: yt2mp3Func,
	ytSearchFunc: ytSearchFunc,
	dplay: dplay
}
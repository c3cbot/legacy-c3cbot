!global.data.rbclist ? global.data.rbclist = {} : ""

var busy = false;
var error = 0;
var estimatedTime = 0;
var msPerChar = 35;
var startTime = 0;
var b = async function (ids, msg, force) {
	busy = true;
	error = 0;
	
	let msPerMsg = (msg.length + 1) * msPerChar;
	let sendTime = 500;
	estimatedTime = ids.length * (msPerMsg + 2000 + sendTime);
	startTime = Date.now();
	
	for (var n in ids) {
		try {
			for (let i = 1; i <= (msPerMsg / 30000).ceil(0); i++) {
				let stopTyping = data.facebookapi.sendTypingIndicator(ids[n]);
				await new Promise(resolve => setTimeout(resolve, (i == (msPerMsg / 30000).ceil(0)) ? (msPerMsg % 30000) : 30000));
				stopTyping();
			}
			let startTime = Date.now();
			await data.facebookapi.sendMessage(`[${force ? "F-" : ""}BROADCAST] ${msg}`, ids[n]);
			sendTime = Date.now() - startTime;
			estimatedTime = ids.length * (msPerMsg + 2000 + sendTime);
			await new Promise(resolve => setTimeout(resolve, 2000));
		} catch (ex) {
			error++;
			if (error >= 10) {
				error = 0;
				throw "10 errors detected. Broadcast stopped.";
			}
			await new Promise(resolve => setTimeout(resolve, 2000));
		}
	}
	busy = false;
	return ids;
}

var broadcast = function (type, data) {
	if (data.admin) {
		var msgtobc = data.msgdata.body.substr(data.args[0].length + 1);
		if (busy) {
			return {
				handler: "internal",
				data: `Please wait ${(estimatedTime + startTime) - Date.now()}ms, the bot is busy broadcasting other messages...`
			}
		} else if (msgtobc == "") {
			return {
				handler: "internal",
				data: `ERR! Empty message.`
			}
		} else {
			var p = Promise.resolve([]);
			if (data.args[0].substr(1) == "broadcast") {
				let thlist = [];
				for (var id in global.data.rbclist) {
					if (global.data.rbclist[id] && thlist.indexOf(id) == -1) {
						thlist.push(id);
					}
				}
				data.log(`Got ${thlist.length} TID to broadcast.`);
				p = Promise.resolve(thlist);
			} else {
				p = (async () => {
					let stopFetch = false;
					let ts = null;
					let v = [];
					while (!stopFetch) {
						try {
							let x = await data.facebookapi.getThreadList(11, ts, ["INBOX"]);
							x.forEach(z => {
								if (z.cannotReplyReason == null && v.indexOf(z.threadID) == -1) v.push(z.threadID);
								ts = z.timestamp;
							});
							if (x.length < 11) stopFetch = true;
						} catch (e) {
							stopFetch = true;
						}
						await new Promise(x => setTimeout(x, 500));
					}
					data.log(`Got ${thlist.length} TID to force-broadcast.`);
					return v;
				})();
			}
			
			p
				.then(thlist => {
					data.return({
						handler: "internal",
						data: `Broadcasting to ${thlist.length} TID...\nETA: ${estimatedTime}ms`
					});
					return thlist;
				})
				.then(thlist => b(thlist, msgtobc, data.args[0].substr(1) == "broadcast"))
				.then(thlist => {
					var timex = Date.now() - startTime;
					data.log(`Done broadcasting to ${thlist.length} TID. Time: ${timex}ms`);
					data.return({
						handler: "internal",
						data: `Done broadcasting to ${thlist.length} TID.\nTime: ${timex}ms`
					});
				})
				.catch(err => {
					data.log(err);
					data.return({
						handler: "internal",
						data: err
					});
				});
			
			new Promise(x => setTimeout(x, 1)).then(() => {
				
			});
		}
	} else {
		return {
			handler: "internal",
			data: "No permission!"
		}
	}
}

var rbc = function (type, data) {
	if (type == "Facebook") {
		!global.data.rbclist[data.msgdata.threadID] ? global.data.rbclist[data.msgdata.threadID] = false : ""
		global.data.rbclist[data.msgdata.threadID] = !global.data.rbclist[data.msgdata.threadID];
		return {
			handler: "internal",
			data: (function () {
				switch (global.data.userLanguage[`FB-${data.msgdata.senderID}`] || global.config.language) {
					case "vi_VN":
						return (global.data.rbclist[data.msgdata.threadID] ? "Đã" : "Hủy") + " đăng kí nhận thông báo Broadcast thành công!";
					case "en_US":
					default:
						return (global.data.rbclist[data.msgdata.threadID] ? "Subscribed" : "Unsubscribed") + " to Broadcast channel!";
				}
			})()
		}
	} else {
		return {
			handler: "internal",
			data: "undefined"
		}
	}
}

module.exports = {
	broadcast: broadcast,
	rbc: rbc
}
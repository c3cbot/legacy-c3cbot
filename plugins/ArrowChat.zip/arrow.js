(typeof global.data.arrowChat != "object" || Array.isArray(global.data.arrowChat)) ? global.data.arrowChat = {} : "";

var random = function random(min, max) {
	if (min > max) {
		var temp = min;
		min = max;
		max = temp;
	}
	var bnum = (max - min).toString(16).length / 2;
	if (bnum < 1) bnum = 1;
	return Math.round(parseInt(global.nodemodule.crypto.randomBytes(bnum).toString('hex'), 16) / Math.pow(16, bnum * 2) * (max - min)) + min; 
}

var show = function show(type, data) {
	var threadID = "";
	switch (type) {
		case "Facebook":
			threadID = "FB-" + data.msgdata.threadID;
			break;
		case "Discord":
			if (data.msgdata.channel.type == "dm") {
				threadID = "DC-" + data.msgdata.channel.id;
			} else {
				threadID = "DC-" + data.msgdata.guild.id;
			}
			break;
		default: 
			return {
				handler: "internal",
				data: "Unsupported interface."
			};
	}
	(typeof global.data.arrowChat[threadID] != "object" || Array.isArray(global.data.arrowChat[threadID])) ?
		global.data.arrowChat[threadID] = {} : "";
	var res = `ArrowChat response list (${Object.keys(global.data.arrowChat[threadID]).length} total): `;
	for (var n in global.data.arrowChat[threadID]) {
		res += `\r\n${n} => ${JSON.stringify(global.data.arrowChat[threadID][n])}`;
	}
	res += "\r\nHow to set a new ArrowChat response: \r\n" + global.config.commandPrefix + "<a> => <b> (example: `" + global.config.commandPrefix + "ping => pong`) or " + global.config.commandPrefix + "<a> => <b> | <c> | <d> (example: `" + global.config.commandPrefix +  "flip a coin => tail | head`)"
	return {
		handler: "internal",
		data: res
	}
}

var del = function del(type, data) {
	var threadID = "";
	switch (type) {
		case "Facebook":
			threadID = "FB-" + data.msgdata.threadID;
			break;
		case "Discord":
			if (data.msgdata.channel.type == "dm") {
				threadID = "DC-" + data.msgdata.channel.id;
			} else {
				threadID = "DC-" + data.msgdata.guild.id;
			}
			break;
		default: 
			return {
				handler: "internal",
				data: "Unsupported interface."
			};
	}
	(typeof global.data.arrowChat[threadID] != "object" || Array.isArray(global.data.arrowChat[threadID])) ?
		global.data.arrowChat[threadID] = {} : "";
	
	if (data.args.length > 1) {
		var ask = data.args.slice(1).join(" ").toLocaleLowerCase();
		var d = delete global.data.arrowChat[threadID][ask];
		return {
			handler: "internal",
			data: d ? `Deleted: ${ask}.` : `Error: No ArrowChat response data found.`
		}
	} else {
		return {
			handler: "internal",
			data: "Error: Missing arguments."
		}
	}	
}

var chathook = function chathook(type, data) {
	var threadID = "";
	var content = "";
	switch (type) {
		case "Facebook":
			switch (data.msgdata.type) {
				case "message":
				case "message_reply":
					threadID = "FB-" + data.msgdata.threadID;
					content = data.msgdata.body;
					if (data.msgdata.senderID == data.facebookapi.getCurrentUserID()) return false;
					break;
				default:
					return false;
			}
			break;
		case "Discord":
			content = data.msgdata.content;
			if (data.msgdata.channel.type == "dm") {
				threadID = "DC-" + data.msgdata.channel.id;
			} else {
				threadID = "DC-" + data.msgdata.guild.id;
			}
			if (data.msgdata.author.id == data.discordapi.user.id) return false;
			break;
		default: 
			return false;
	}
	(typeof global.data.arrowChat[threadID] != "object" || Array.isArray(global.data.arrowChat[threadID])) ?
		global.data.arrowChat[threadID] = {} : "";
	var args = content
		.replace((/”/g), "\"")
		.replace((/“/g), "\"")
		.split(/((?:"[^"\\]*(?:\\[\S\s][^"\\]*)*"|'[^'\\]*(?:\\[\S\s][^'\\]*)*'|\/[^/\\]*(?:\\[\S\s][^/\\]*)*\/[gimy]*(?=\s|$)|(?:\\\s|\S))+)(?=\s|$)/)
		.filter(el => !(el == null || el == "" || el == " "))
		.map(xy => xy.replace(/"/g, ""));	
	
	if (typeof global.data.arrowChat[threadID][content.toLocaleLowerCase()] == "object" 
		&& Array.isArray(global.data.arrowChat[threadID][content.toLocaleLowerCase()])
		&& !content.startsWith(global.config.commandPrefix)) {
		var y = "";
		for (var z = 0; z < random(1, 15); z++) y += "  ";
		data.return({
			handler: "internal",
			data: global.data.arrowChat[threadID][content.toLocaleLowerCase()][random(0, global.data.arrowChat[threadID][content.toLocaleLowerCase()].length - 1)].replace(/@everyone/g, "@  everyone").replace(/@/g, "@" + y);
		});
		return true;
	} else if (content.startsWith(global.config.commandPrefix) && args.length >= 3) {
		var arrowIndex = args.indexOf("=>");
		if (arrowIndex <= 0) return false;
		var ask = args.slice(0, arrowIndex).join(" ").substr(1).toLocaleLowerCase();
		var answer = args.slice(arrowIndex + 1).join(" ").split("|");
		if (answer.length == 0) return false;
		global.data.arrowChat[threadID][ask] = answer;
		data.return({
			handler: "internal",
			data: `OK! \r\nSay: ${ask}\r\nAnswer: ${JSON.stringify(answer)}`
		});
		return true;
	}
	return false;
}

module.exports = {
	show: show,
	del: del,
	chathook: chathook
}
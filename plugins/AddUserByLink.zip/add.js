var langMap = {
	"en_US": {
		"invalidArgs": "Error: Invalid argument!",
		"cannotAddUser": "Error: Cannot add user {0} to this group!",
		"added": "Added user {0} to this group.",
		"cannotGetThreadInfo": "Error: Cannot get this group's info!",
		"addedToBeApproved": "Added user {0} to member approval list.",
		"approvalModeEnabled": "Error: Cannot add user {0} to this group because admin approval mode is enabled and you are not a group admin.",
		"wait": "Please wait {0} seconds before executing this command.",
		"cannotCreateNewGroup": "Error: Cannot create a new group with user {0}!",
		"cannotAddAdminStatus": "Warning: Cannot add admin status for you in the new group.",
		"createdNewThread": "Created a new group with user {0}.",
		"cannotGetID": "Error: Cannot get userID from that URL (blocked?)",
		"invalidURL": "Error: The URL you specified is not a Facebook URL."
	},
	"vi_VN": {
		"invalidArgs": "Lỗi: URL không hợp lệ!",
		"cannotAddUser": "Lỗi: Không thể thêm user {0} vào nhóm này!",
		"added": "Đã thêm user {0} vào nhóm này.",
		"cannotGetThreadInfo": "Lỗi: Không thể lấy thông tin nhóm này!",
		"addedToBeApproved": "Đã thêm user {0} vào danh sách phê duyệt thành viên.",
		"approvalModeEnabled": "Lỗi: Không thể thêm user {0} vào nhóm này vì phê duyệt thành viên được bật và bạn không phải là admin group.",
		"wait": "Vui lòng chờ {0} giây trước khi thực hiện thêm lệnh này.",
		"cannotCreateNewGroup": "Lỗi: Không thể tạo nhóm mới với user {0}!",
		"cannotAddAdminStatus": "Cảnh báo: Không thể thêm quyền admin cho bạn ở nhóm mới.",
		"createdNewThread": "Đã tạo nhóm mới với user {0}.",
		"cannotGetID": "Lỗi: Không thể lấy userID từ URL đó (blocked?)",
		"invalidURL": "Lỗi: URL bạn đã cung cấp không phải là URL của Facebook."
	}
}
var getLang = function () {}
var onLoad = function (data) {
	var log = data.log;
	getLang = function (langVal, id) {
	  var lang = global.config.language;
	  if (id && global.data.userLanguage[id]) {
		lang = global.data.userLanguage[id];
		if (!langMap[lang]) {
		  log("Warning: Invalid language: ", lang, `; using ${global.config.language} as fallback...`);
		  lang = global.config.language;
		}
	  }

	  if (langMap[lang]) {
		return String(langMap[lang][langVal]);
	  } else {
		log("Warning: Invalid language: ", lang, "; using en_US as fallback...");
		return String((langMap["en_US"] || {})[langVal]);
	  }
	}
}

typeof global.data.createGroupCooldown != "object" ? global.data.createGroupCooldown = {} : "";

var adduser = function (type, data) {
	if (type != "Facebook") {
		return {
			handler: "internal",
			data: null
		}
	}
	
	var url = data.args[1];
	try {
		var parsed = new URL(url);
	} catch (ex) {
		return {
			handler: "internal", 
			data: getLang("invalidArgs", `FB-${data.msgdata.senderID}`)
		}
	}
	switch (parsed.hostname) {
		case "www.facebook.com":
		case "facebook.com":
		case "fb.com":
		case "fb.me":
		case "m.me":
		case "m.facebook.com":
		case "mbasic.facebook.com":
		case "facebookcorewwwi.onion":
			parsed.hostname = "mbasic.facebook.com";
			parsed.protocol = "https";
			data.facebookapi.httpGet(parsed.href, {}, function (err, html) {
				if (err) {
					return data.return({
						handler: "internal",
							data: err.toString()
					});
				}
				var urlwithid = (
					//html.match(/("\/mbasic\/more\/\?owner_id=)(.+?)(")/g) || 
					html.match(new RegExp(`\/about\\?lst=${facebook.api.getCurrentUserID()}%3A(.+?)%3A`, "g")) || 
					[]
				)[0];
				if (urlwithid) {
					//urlwithid = decodeURIComponent(urlwithid.substr(1, urlwithid.length - 2));
					var p = new URL(urlwithid, "https://mbasic.facebook.com");
					//var id = p.searchParams.get("owner_id");
					var id = p.searchParams.get("lst").split(":")[1];
					data.log(`Got ID of profile URL ${url}: ${id}`);
					if (data.msgdata.isGroup) {
						data.facebookapi.getThreadInfo(data.msgdata.threadID)
							.then(function (gInfo) {
								if (gInfo.approvalMode) {
									if (gInfo.adminIDs.indexOf(data.facebookapi.getCurrentUserID()) + 1) {
										if (gInfo.adminIDs.indexOf(data.msgdata.senderID) + 1) {
											data.facebookapi.addUserToGroup(id, data.msgdata.threadID, function (err) {
												if (err) {
													return data.return({
														handler: "internal",
														data: getLang("cannotAddUser", `FB-${data.msgdata.senderID}`).replace("{0}", id)
													});
												}
												return data.return({
													handler: "internal",
													data: getLang("added", `FB-${data.msgdata.senderID}`).replace("{0}", id)
												});
											});
										} else {
											return data.return({
												handler: "internal",
												data: getLang("approvalModeEnabled", `FB-${data.msgdata.senderID}`).replace("{0}", id)
											});
										}
									} else {
										data.facebookapi.addUserToGroup(id, data.msgdata.threadID, function (err) {
											if (err) {
												return data.return({
													handler: "internal",
													data: getLang("cannotAddUser", `FB-${data.msgdata.senderID}`).replace("{0}", id)
												});
											}
											return data.return({
												handler: "internal",
												data: getLang("addedToBeApproved", `FB-${data.msgdata.senderID}`).replace("{0}", id)
											});
										});
									}
								} else {
									data.facebookapi.addUserToGroup(id, data.msgdata.threadID, function (err) {
										if (err) {
											return data.return({
												handler: "internal",
												data: getLang("cannotAddUser", `FB-${data.msgdata.senderID}`).replace("{0}", id)
											});
										}
										return data.return({
											handler: "internal",
											data: getLang("added", `FB-${data.msgdata.senderID}`).replace("{0}", id)
										});
									});
								}
							})
							.catch(function (err) {
								data.log("An error was returned from Facebook while trying to get thread info:", err);
								return data.return({
									handler: "internal",
									data: getLang("added", `FB-${data.msgdata.senderID}`).replace("{0}", id)
								});
							});
					} else {
						if (!isNaN(Number(global.data.createGroupCooldown[data.msgdata.senderID])) &&
							global.data.createGroupCooldown[data.msgdata.senderID] > Date.now()) {
								return date.return({
									handler: "internal",
									data: getLang("wait", `FB-${data.msgdata.senderID}`).replace("{0}", ((global.data.createGroupCooldown[data.msgdata.senderID] - Date.now()) / 1000).ceil(0))
								});
							}
						
						global.data.createGroupCooldown[data.msgdata.senderID] = Date.now() + (60 * 1000) + Math.round(Math.random() * 10000);
						data.facebookapi.createNewGroup([
							data.msgdata.senderID,
							id
						], null, function (err, newThreadID) {
							if (err) {
								return data.return({
									handler: "internal",
									data: getLang("cannotCreateNewGroup", `FB-${data.msgdata.senderID}`).replace("{0}", id)
								});
							}
							data.facebookapi.changeAdminStatus(newThreadID, data.msgdata.senderID, true, function (err) {
								if (err) {
									data.return({
										handler: "internal",
										data: getLang("cannotAddAdminStatus", `FB-${data.msgdata.senderID}`)
									});
								}
								setTimeout(function () {
									var requested = "@" + global.data.cacheName["FB-" + data.msgdata.senderID];
									var rtmsg = `${data.prefix} Created this thread as requested by ${requested}.`;
									data.facebookapi.sendMessage({
										body: rtmsg,
										mentions: [
											{
												tag: requested,
												id: data.msgdata.senderID
											}
										]
									}, newThreadID, () => {}, null, true);
								}, 1500);
								data.return({
									handler: "internal",
									data: getLang("createdNewThread", `FB-${data.msgdata.senderID}`).replace("{0}", id)
								});
							});
						});
					}
				} else {
					data.return({
						handler: "internal",
						data: getLang("cannotGetID", `FB-${data.msgdata.senderID}`)
					});
				}
			}, true);
			break;
		default:
			return {
				handler: "internal",
				data: getLang("invalidURL", `FB-${data.msgdata.senderID}`)
			}
	}
}

module.exports = {
	adduser: adduser,
	onLoad
}
typeof global.data.createGroupCooldown != "object" ? global.data.createGroupCooldown = {} : "";

var adduser = function (type, data) {
	if (type != "Facebook") {
		return {
			handler: "internal",
			data: null
		}
	}
	
	var url = data.args[1];
	try {
		var parsed = new URL(url);
	} catch (ex) {
		return {
			handler: "internal", 
			data: "Error: Not a valid URL."
		}
	}
	switch (parsed.hostname) {
		case "www.facebook.com":
		case "facebook.com":
		case "fb.com":
		case "fb.me":
		case "m.me":
		case "m.facebook.com":
		case "mbasic.facebook.com":
		case "facebookcorewwwi.onion":
			parsed.hostname = "mbasic.facebook.com";
			parsed.protocol = "https";
			data.facebookapi.httpGet(parsed.href, {}, function (err, html) {
				if (err) {
					return data.return({
						handler: "internal",
							data: err.toString()
					});
				}
				var urlwithid = (html.match(/("\/mbasic\/more\/\?owner_id=)(.+?)(")/g) || [])[0];
				if (urlwithid) {
					urlwithid = decodeURIComponent(urlwithid.substr(1, urlwithid.length - 2));
					var p = new URL(urlwithid, "https://mbasic.facebook.com");
					var id = p.searchParams.get("owner_id");
					data.log(`Got ID of profile URL ${url}: ${id}`);
					if (data.msgdata.isGroup) {
						data.facebookapi.addUserToGroup(id, data.msgdata.threadID, function (err) {
							if (err) {
								return data.return({
									handler: "internal",
									data: `Error: Cannot add user ${id} to this group.`
								});
							}
							return data.return({
								handler: "internal",
								data: `Added user ${id} to this group.`
							});
						});
					} else {
						if (!isNaN(Number(global.data.createGroupCooldown[data.msgdata.senderID])) &&
							global.data.createGroupCooldown[data.msgdata.senderID] > Date.now()) {
								return date.return({
									handler: "internal",
									data: `Please wait ${((global.data.createGroupCooldown - Date.now()) / 1000).ceil(0)}s before request creating new thread!`
								});
							}
						
						global.data.createGroupCooldown[data.msgdata.senderID] = Date.now() + (60 * 1000) + Math.round(Math.random() * 10000);
						data.facebookapi.createNewGroup([
							data.msgdata.senderID,
							id
						], null, function (err, newThreadID) {
							if (err) {
								return data.return({
									handler: "internal",
									data: `Cannot create new group with ID ${id}!`
								});
							}
							data.facebookapi.changeAdminStatus(newThreadID, data.msgdata.senderID, true, function (err) {
								if (err) {
									data.return({
										handler: "internal",
										data: "Warning: Cannot add admin status for you in new group."
									});
								}
								setTimeout(function () {
									var requested = "@" + global.data.cacheName["FB-" + data.msgdata.senderID];
									var rtmsg = `${data.prefix} Created this thread as requested by ${requested}.`;
									data.facebookapi.sendMessage({
										body: rtmsg,
										mentions: [
											{
												tag: requested,
												id: data.msgdata.senderID
											}
										]
									}, newThreadID, () => {}, null, true);
								}, 1500);
								data.return({
									handler: "internal",
									data: `Created a new thread with ID ${id}.`
								});
							});
						});
					}
				} else {
					data.return({
						handler: "internal",
						data: "Error: Cannot get ID from that profile. (blocked?)"
					});
				}
			}, true);
			break;
		default:
			return {
				handler: "internal",
				data: "Error: Not a valid Facebook profile URL."
			}
	}
}

module.exports = {
	adduser: adduser
}
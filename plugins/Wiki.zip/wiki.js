var fetch = global.nodemodule["node-fetch"];
var path = global.nodemodule["path"];
var streamBuffers = global.nodemodule["stream-buffers"]
var wiki = function wiki(type, data) {
	(async function () {
		var sT = data.args.slice(1).join(" ")
		var sS = encodeURIComponent(sT)
		if (sT === '') {
			return {
				handler: "internal",
				data: "`"+global.config.commandPrefix + "wiki <keyword>`\r\n[Seach on Wikipedia]"
			}
		} else {
			try {
				data.return({
					handler: "internal",
					data: "Searching..."
				});
				var api = `https://${data.resolvedLang}.wikipedia.org/w/api.php?format=json&action=query&prop=extracts&exintro&explaintext&redirects=1&titles=${sS}`
				var img = `https://${data.resolvedLang}.wikipedia.org/w/api.php?action=query&titles=${sS}&prop=pageimages&format=json&pithumbsize=720`
				data.log("Keyword: "+sT);
				var fetchdata = await fetch(api);
				var fetchimg = await fetch(img);
				var js = await fetchimg.text();
				var json = await fetchdata.text();
				var dbtm = `${js}`;
				var dbt = `${json}`;
				var suggestionData = JSON.parse(dbt);
				var pageid = Object.keys(suggestionData.query.pages)[0];
				var tI = suggestionData.query.pages[pageid].title;
				var eX = suggestionData.query.pages[pageid].extract;
				var title = tI.toString('utf-8');
				var text = eX.toString('utf-8');
				var imgD = JSON.parse(dbtm);
				var pgid = Object.keys(imgD.query.pages)[0];
				if (imgD.query.pages[pgid].thumbnail == undefined) {
					return {
						handler: "internal",
						data: `Result: ${title}\r\n\n- ${text}`
					}
				} else {
					var imgX = imgD.query.pages[pgid].thumbnail.source;
					var fetchimgD = await fetch(imgX);
					var buffer = await fetchimgD.buffer();
						var imagesx = new streamBuffers.ReadableStreamBuffer({
							frequency: 10,
							chunkSize: 1024
						});
						imagesx.path = 'image.png';
						imagesx.put(buffer);
						imagesx.stop();
						return {
							handler: "internal",
							data: {
								body: `Result: ${title}\r\n\n- ${text}`,
								attachment: ([imagesx])
							}
						}
				}
			} catch(er) {
				data.log(er)
				return {
					handler: "internal",
					data: 'Data not found!\r\n`'+ global.config.commandPrefix
				}
			}
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
}
module.exports = {
	wiki: wiki
}
let base32 = global.nodemodule.base32;

var base64 = function base64(type, data) {
	if (data.args.length > 2) {
		switch (data.args[1].toLocaleLowerCase()) {
			case "decode":
				try {
					return {
						handler: "internal",
						data: `\`\`\`\n${Buffer.from(data.args[2], "base64").toString('utf8')}\n\`\`\``
					}
				} catch (ex) {
					return {
						handler: "internal",
						data: `Invalid Base64!`
					}
				}
				break;
			case "encode":
				return {
					handler: "internal",
					data: `\`\`\`\n${Buffer.from(data.args.slice(2).join(" ")).toString('base64')}\n\`\`\``
				}
				break;
			default:
				return {
					handler: "internal",
					data: "Invalid mode!"
				}
		}
	} else {
		return {
			handler: "internal",
			data: "Invalid arguments!"
		}
	}
}

var base32f = function base64(type, data) {
	if (data.args.length > 2) {
		switch (data.args[1].toLocaleLowerCase()) {
			case "decode":
				try {
					return {
						handler: "internal",
						data: `\`\`\`\n${base32.decode(data.args[2])}\n\`\`\``
					}
				} catch (ex) {
					return {
						handler: "internal",
						data: `Invalid Base64!`
					}
				}
				break;
			case "encode":
				return {
					handler: "internal",
					data: `\`\`\`\n${base32.encode(data.args.slice(2).join(" "))}\n\`\`\``
				}
				break;
			default:
				return {
					handler: "internal",
					data: "Invalid mode!"
				}
		}
	} else {
		return {
			handler: "internal",
			data: "Invalid arguments!"
		}
	}
}

module.exports = {
	base64,
	base32f
}
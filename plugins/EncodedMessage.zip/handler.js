let b32e = global.nodemodule.base32;
let b2048e = global.nodemodule.base2048;
let b65536e = global.nodemodule.base65536;
let braillee = global.nodemodule["braille-encode"];
let ecojie = global.nodemodule["ecoji-js"];
let morsee = global.nodemodule.xmorse;
let wtf8 = global.nodemodule["wtf-8"];

let elist = {
	base32: {
		encode: true,
		decode: true,
		func: function base32(encode, data) {
			data = data + "";
			if (encode) {
				return b32e.encode(wtf8.encode(data)).toUpperCase();
			} else {
				return wtf8.decode(b32e.decode(data.toLowerCase()));
			}
		}
	},
	base64: {
		encode: true,
		decode: true,
		func: function base64(encode, data) {
			data = data + "";
			if (encode) {
				return Buffer.from(data).toString("base64");
			} else {
				return Buffer.from(data, "base64").toString("utf8");
			}
		}
	},
	hex: {
		encode: true,
		decode: true,
		func: function hex(encode, data) {
			data = data + "";
			if (encode) {
				return wtf8.encode(data).split("").map(x => x.charCodeAt(0).toString(16).pad(2)).join("").toUpperCase();
			} else {
				return wtf8.decode(data.toUpperCase().replace(/((?![A-F0-9])(\s|\S))*/g, "").match(/.{1,2}/g).map(x => String.fromCharCode(parseInt(x, 16))).join(""));
			}
		}
	},
	base65536: {
		encode: true,
		decode: true,
		func: function base65536(encode, data) {
			data = data + "";
			if (encode) {
				return b65536e.encode(new Uint8Array(wtf8.encode(data).split("").map(x => x.charCodeAt(0))));
			} else {
				return wtf8.decode(Array.from(b65536e.decode(data)).map(x => String.fromCharCode(x)).join(""));
			}
		}
	},
	base2048: {
		encode: true,
		decode: true,
		func: function base2048(encode, data) {
			data = data + "";
			if (encode) {
				return b2048e.encode(new Uint8Array(wtf8.encode(data).split("").map(x => x.charCodeAt(0))));
			} else {
				return wtf8.decode(Array.from(b2048e.decode(data)).map(x => String.fromCharCode(x)).join(""));
			}
		}
	},
	braille: {
		encode: true,
		decode: true,
		func: function braille(encode, data) {
			data = data + "";
			if (encode) {
				return braillee.encode(Buffer.from(wtf8.encode(data).split("").map(x => x.charCodeAt(0))));
			} else {
				let d = braillee.decode(data);
				return wtf8.decode(Array.from(new Int8Array(d.buffer, d.byteOffset, d.length)).map(x => String.fromCharCode(x)).join(""));
			}
		}
	},
	ecoji: {
		encode: true,
		decode: true,
		func: function ecoji(encode, data) {
			data = data + "";
			if (encode) {
				return ecojie.encode(wtf8.encode(data));
			} else {
				return wtf8.decode(ecojie.decode(data.replace(/`/g, "")));
			}
		}
	},
	morse: {
		encode: true,
		decode: true,
		func: function morse(encode, data) {
			data = data + "";
			let opt = {
				space: " ",
				long: "-",
				short: "."
			}
			if (encode) {
				return morsee.encode(data, opt);
			} else {
				return morsee.decode(data, opt);
			}
		}
	}
}

function getSyntaxErr() {
	let aed = Object.entries(elist).reduce((a, v) => {
		if (v[1].encode) a += (a != "" ? "; " : "") + "e." + v[0];
		if (v[1].decode) a += (a != "" ? "; " : "") + "d." + v[0];
		return a;
	}, "");
	return {
		handler: "internal",
		data: `SYNTAX ERR!\n\`${global.config.commandPrefix}encoder <e.base64/d.base64/...> <msg/encoded msg>\`\nChainable! (ex: \`${global.config.commandPrefix}encoder e.base64,e.base32 test message\`)\nAvailable (e)ncoder/(d)ecoder: ${aed}`
	}
}

let inf = async function inf(type, data) {
	if (data.args.length > 2) {
		let algo = data.args[1].split(",").map(x => x.trim());
		let msg = data.args.slice(2).join(" ");
		for (let n in algo) {
			if (algo[n].startsWith("e.")) {
				if (elist.hasOwnProperty(algo[n].slice(2))) {
					try {
						msg = elist[algo[n].slice(2)].func(true, msg);
					} catch (_) {
						return {
							handler: "internal",
							data: `Error while encoding with ${algo[n]}. ${_}`
						}
					}
				} else {
					return getSyntaxErr();
				}
			} else if (algo[n].startsWith("d.")) {
				if (elist.hasOwnProperty(algo[n].slice(2))) {
					try {
						msg = elist[algo[n].slice(2)].func(false, msg);
					} catch (_) {
						return {
							handler: "internal",
							data: `Error while decoding with ${algo[n]}. ${_}`
						}
					}
				} else {
					return getSyntaxErr();
				}
			} else {
				return getSyntaxErr();
			}
		}
		return {
			handler: "internal",
			data: (type === "Discord" ? "```\n" : "") + msg + (type === "Discord" ? "\n```" : "")
		}	
	} else {
		return getSyntaxErr();
	}
}

module.exports = {
	elist,
	inf
}
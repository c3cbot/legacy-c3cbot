// function sizeObject(object) {
  // return Object.keys(object).length;
// }

typeof global.data.giftcode != "object" ? global.data.giftcode = {} : "";

var redeemfunc = function redeemfunc(type, data) {
	var Economy = global.plugins.economy;
	if (data.args.length > 1) {
		var giftcode = data.args[1];
		if (global.data.giftcode.hasOwnProperty(giftcode)) {
			if (global.data.giftcode[giftcode].times >= 1) {
				global.data.giftcode[giftcode].times -= 1;
				Economy.operator.add(Economy.getID(data.msgdata, type), global.data.giftcode[giftcode].amount, `Giftcode: Redeem code ${giftcode}`);
				return {
					handler: "internal",
					data: `Redeemed code \`${giftcode}\` and received ${global.data.giftcode[giftcode].amount.floor(2)}${Economy.getSymbol()}.`
				}
			} else {
				return {
					handler: "internal",
					data: `Error: This code is ${global.data.giftcode[giftcode].times != 0 ? "locked by the issuer." : "no longer usable. (0 times left)"}`
				}	
			}	
		} else {
			return {
				handler: "internal",
				data: "Error: Invalid giftcode!"
			}
		}
	} else {
		return {
			handler: "internal", 
			data: "Error: undefined"
		}
	}
}

var createfunc = function createfunc(type, data) {
	var Economy = global.plugins.economy;
	if (data.args.length > 1) {
		var id = Economy.getID(data.msgdata, type);
		var times = 1;
		if (data.args.length > 2) {
			times = parseInt(data.args[2]);
			if (isNaN(times) || (times < 1)) {
				times = 1;
			}
		}
		var amount = Math.abs(Economy.parseValue(id, data.args[1]));
		if (!Economy.validBalance(id, amount * times)) {
			return {
				handler: "internal",
				data: `Not enough money (${Economy.getBalance(id).floor(2)}${Economy.getSymbol()}/${amount.ceil(2)}${Economy.getSymbol()})`
			}
		}
		
		var giftcode = "";
		var needRandom = true;
		while (needRandom) {
			giftcode = Math.random().toString(36).replace(/[^a-z0-9]+/g, '').substr(1, 8) + 
				Math.random().toString(36).replace(/[^a-z0-9]+/g, '').substr(1, 8);
			giftcode = giftcode.toLocaleUpperCase();
			if (!global.data.giftcode.hasOwnProperty(giftcode))
				needRandom = false;
		}
		Economy.operator.subtract(id, amount * times, `Giftcode: Create code ${giftcode} with ${times} times`);
		global.data.giftcode[giftcode] = {
			amount: amount,
			times: times,
			issuedBy: id
		}
		return {
			handler: "internal",
			data: `Created giftcode \`${giftcode}\` with ${times} times left, each time receive ${amount.floor(2)}${Economy.getSymbol()}.`
		}
	} else {
		return {
			handler: "internal",
			data: "Error: undefined"
		}
	}
}

var lockfunc = function lockfunc(type, data) {
	var Economy = global.plugins.economy;
	var id = Economy.getID(data.msgdata, type);
	if (data.args.length > 1) {
		var giftcode = data.args[1];
		if (global.data.giftcode.hasOwnProperty(giftcode)) {
			if (global.data.giftcode[giftcode].issuedBy == id) {
				var locked = Math.sign(global.data.giftcode[giftcode].times) == -1;
				global.data.giftcode[giftcode].times *= -1;
				return {
					handler: "internal",
					data: `Successfully ${!locked ? "" : "un"}locked ${Math.abs(global.data.giftcode[giftcode].times)} times of that giftcode.`
				}
			} else {
				return {
					handler: "internal",
					data: "Error: You are not the issuer of that giftcode!"
				}
			}
		} else {
			return {
				handler: "internal",
				data: "Invalid giftcode!"
			}
		}
	}
}

module.exports = {
	createfunc: createfunc,
	redeemfunc: redeemfunc
}
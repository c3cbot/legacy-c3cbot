!global.data.ecoGambling ? global.data.ecoGambling = {
	blackjack: {}
} : "";

//Library
var random = function(min, max) { 
	// if (min > max) {
		// var temp = min;
		// min = max;
		// max = temp;
	// }
	// var bnum = (max - min).toString(16).length / 2;
	// if (bnum < 1) bnum = 1;
	// return Math.round(parseInt(global.nodemodule.crypto.randomBytes(bnum).toString('hex'), 16) / Math.pow(16, bnum * 2) * (max - min)) + min; 
	return global.plugins.librandom.getRandomNumber(min, max, 0);
};

var availableLanguage = {
	"en_US": "eco_gambling_langpack_en_US",
	"vi_VN": "eco_gambling_langpack_vi_VN"
}

var langfile = global.fileMap[availableLanguage[global.config.language]];
var languagePack = global.nodemodule["js-yaml"].load(langfile.toString());

diceFunction = function(type, data) {
	var Economy = global.plugins.economy;
	var { getID, getSymbol, getBalance, validBalance, parseValue, validWallet } = Economy;
	var OPCODE = Economy.operator;

	var id = getID(data.msgdata, type);
	validWallet(id);
	if (data.args.length > 3) {
		var rt = function(data) {
			return {
				handler: "internal",
				data: data
			}
		}
		var betsize = Math.abs(parseValue(id, data.args[1]));
		var direction = data.args[2];
		var prediction = parseFloat(data.args[3]).round();
		var houseEdge = 1;
		
		if (!validBalance(id, betsize))
			return rt(languagePack["NOT_ENOUGH_MONEY"]
				.replace("{0}", global.data.economy[id])
				.replace("{1}", Math.abs(betsize)));
				
		if (betsize == 0)
			return rt(languagePack["CANNOT_BET_0"]);
		
		if (direction != "over" && direction != "under") 
			return rt(languagePack["DICE_UNKNOWN_DIRECTION"].replace("{0}", direction));
			
		if (prediction < houseEdge || prediction > 99 - houseEdge || isNaN(prediction))
			return rt(languagePack["DICE_PREDICTION_OUT_OF_RANGE"].replace("{0}", houseEdge).replace("{1}", 99 - houseEdge));
		
		OPCODE.subtract(id, betsize, data.args.join(" "));
		var randomNumber = random(0, 99);
		var payout = Math.abs((100 - houseEdge) / (direction == "under" ? prediction : (100 - houseEdge) - prediction) * betsize);
		if (direction == "over") {
			if (randomNumber > prediction) {
				OPCODE.add(id, payout, data.args.join(" "));
				return rt(languagePack["DICE_WIN_MESSAGE"]
					.replace("{0}", (payout - betsize).floor(2) + getSymbol())
					.replace("{1}", randomNumber)
					.replace("{2}", global.data.cacheName[id] + " - " + OPCODE.get(id).floor(2) + getSymbol())
				);
			} else {
				return rt(languagePack["DICE_LOSE_MESSAGE"]
					.replace("{0}", betsize.floor(2) + getSymbol())
					.replace("{1}", randomNumber)
					.replace("{2}", global.data.cacheName[id] + " - " + OPCODE.get(id).floor(2) + Economy.getSymbol())
				);
			}
		} else if (direction == "under") {
			if (randomNumber < prediction) {
				OPCODE.add(id, payout, data.args.join(" "));
				return rt(languagePack["DICE_WIN_MESSAGE"]
					.replace("{0}", (payout - betsize).floor(2) + getSymbol())
					.replace("{1}", randomNumber)
					.replace("{2}", global.data.cacheName[id] + " - " + OPCODE.get(id).floor(2) + getSymbol())
				);
			} else {
				return rt(languagePack["DICE_LOSE_MESSAGE"]
					.replace("{0}", betsize.floor(2) + getSymbol())
					.replace("{1}", randomNumber)
					.replace("{2}", global.data.cacheName[id] + " - " + OPCODE.get(id).floor(2) + getSymbol())
				);
			}
		}
	} else {
		return {
			handler: "internal",
			data: "Too few arguments!"
		}
	}
}

!global.data.rouletteData ? global.data.rouletteData = {} : "";
var rouletteRedNumber = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36];
rouletteFunction = function (type, data) {
	var Economy = global.plugins.economy;
	var { getID, getSymbol, getBalance, validBalance, parseValue, validWallet } = Economy;
	var OPCODE = Economy.operator;
	
	var rt = function(data) {
		return {
			handler: "internal",
			data: data
		}
	}
	var id = getID(data.msgdata, type);
	validWallet(id);
	!global.data.rouletteData[id] ? global.data.rouletteData[id] = [] : "";
	var houseEdge = 1;
	var rateLeft = 37 - houseEdge;
	if (data.args.length > 1) {
		switch (data.args[1]) {
			case "bet":
				if (data.args.length > 3) {
					var betsize = Math.abs(parseValue(id, data.args[2]));
					var betslot = "";
					switch (data.args[3].toLocaleLowerCase()) {
						case "1-18":
						case "19-36":
						case "1-12":
						case "13-24":
						case "25-36":
						case "even":
						case "odd":
						case "red":
						case "black":
						case "green":
						case "1st":
						case "2nd":
						case "3rd":
							betslot = data.args[3].toLocaleLowerCase();
							break;
						default:
							var ind = parseInt(data.args[3].toLocaleLowerCase());
							if (!isNaN(ind) && ind <= 36 && ind >= 0) {
								betslot = parseInt(data.args[3]).toString();
							}
					}
					if (betslot == "") {
						return rt(languagePack["ROULETTE_UNKNOWN_BET_SLOT"]);
					} else if (isNaN(betsize)) {
						return rt(languagePack["IS_NAN"]);
					} else if (!validBalance(id, betsize)) {
						return rt(languagePack["NOT_ENOUGH_MONEY"]
							.replace("{0}", getBalance(id).floor(2) + getSymbol())
							.replace("{1}", betsize.ceil(2) + getSymbol())
						);
					} else if (betsize === 0) {
						return rt(languagePack["CANNOT_BET_0"]);
					} else {
						OPCODE.subtract(id, betsize, data.args.join(" "));
						global.data.rouletteData[id].push({
							size: betsize,
							slot: betslot
						});
						return rt(languagePack["ROULETTE_PLACED_BET"]
							.replace("{0}", betsize + getSymbol())
							.replace("{1}", betslot)
						);
					}
				} else {
					return rt(languagePack["ROULETTE_UNKNOWN_ARG"]);
				}
				break;
			case "start":
				if (global.data.rouletteData[id].length === 0) {
					return rt(languagePack["ROULETTE_NO_BET"]);
				} else {
					var rnd = random(0, 36);
					var winbet = [];
					global.data.rouletteData[id] = global.data.rouletteData[id].filter(x => x != null);
					for (var n in global.data.rouletteData[id]) {
						switch (global.data.rouletteData[id][n].slot) {
							case "1-18":
								if (rnd >= 1 && rnd <= 18) {
									global.data.rouletteData[id][n].multiplier = rateLeft / 18;
									winbet.push(global.data.rouletteData[id][n]);
								}
								break;
							case "19-36":
								if (rnd >= 19 && rnd <= 36) {
									global.data.rouletteData[id][n].multiplier = rateLeft / 18;
									winbet.push(global.data.rouletteData[id][n]);
								}
								break;
							case "1-12":
								if (rnd >= 1 && rnd <= 12) {
									global.data.rouletteData[id][n].multiplier = rateLeft / 12;
									winbet.push(global.data.rouletteData[id][n]);
								}
								break;
							case "13-24":
								if (rnd >= 13 && rnd <= 24) {
									global.data.rouletteData[id][n].multiplier = rateLeft / 12;
									winbet.push(global.data.rouletteData[id][n]);
								}
								break;
							case "25-36":
								if (rnd >= 25 && rnd <= 36) {
									global.data.rouletteData[id][n].multiplier = rateLeft / 12;
									winbet.push(global.data.rouletteData[id][n]);
								}
								break;
							case "even":
								if (!(rnd % 2) && rnd != 0) {
									global.data.rouletteData[id][n].multiplier = rateLeft / 18;
									winbet.push(global.data.rouletteData[id][n]);
								}
								break;
							case "odd":
								if (rnd % 2 && rnd != 0) {
									global.data.rouletteData[id][n].multiplier = rateLeft / 18;
									winbet.push(global.data.rouletteData[id][n]);
								}
								break;
							case "red":
								if (rouletteRedNumber.includes(rnd)) {
									global.data.rouletteData[id][n].multiplier = rateLeft / rouletteRedNumber.length;
									winbet.push(global.data.rouletteData[id][n]);
								}
								break;
							case "black":
								if (!rouletteRedNumber.includes(rnd)) {
									global.data.rouletteData[id][n].multiplier = rateLeft / (36 - rouletteRedNumber.length);
									winbet.push(global.data.rouletteData[id][n]);
								}
								break;
							case "green":
							case "0":
								if (rnd == 0) {
									global.data.rouletteData[id][n].multiplier = 36;
									winbet.push(global.data.rouletteData[id][n]);
								}
								break;
							case "1st":
								if (rnd % 3 == 1 && rnd != 0) {
									global.data.rouletteData[id][n].multiplier = rateLeft / 12;
									winbet.push(global.data.rouletteData[id][n]);
								}
								break;
							case "2nd":
								if (rnd % 3 == 2 && rnd != 0) {
									global.data.rouletteData[id][n].multiplier = rateLeft / 12;
									winbet.push(global.data.rouletteData[id][n]);
								}
								break;
							case "3rd":
								if (rnd % 3 == 0 && rnd != 0) {
									global.data.rouletteData[id][n].multiplier = rateLeft / 12;
									winbet.push(global.data.rouletteData[id][n]);
								}
								break;
							default:
								var num = parseInt(global.data.rouletteData[id][n].slot);
								if (!isNaN(num)) {
									if (num == rnd) {
										global.data.rouletteData[id][n].multiplier = 36;
										winbet.push(global.data.rouletteData[id][n]);
									}
								}
						}
					}
					var payout = 0;
					var textout = "";
					for (var m in winbet) {
						payout += winbet[m].multiplier * winbet[m].size;
						textout += "\r\n" + winbet[m].size.floor(2) + getSymbol() + " => " + (winbet[m].multiplier * winbet[m].size).floor(2) + getSymbol() + " (" + winbet[m].multiplier + "x - " + languagePack["SLOT"] + " " + winbet[m].slot + ")";
					}
					if (textout == "") textout = "\r\nNo winned bet.";
					global.data.rouletteData[id] = [];
					OPCODE.add(id, payout, data.args.join(" ") + " | " + rnd);
					return rt(languagePack["ROULETTE_BET_RESULT"].replace("{0}", rnd) + textout);
				}
				break;
			case "betlist":
				var returndata = languagePack["ROULETTE_BETLIST_PREFIX"];
				for (var n in global.data.rouletteData[id]) {
					returndata += "\r\n" + (parseInt(n) + 1) + ". " + global.data.rouletteData[id][n].size.floor(2) + getSymbol() + " - " + languagePack["SLOT"] + " " + global.data.rouletteData[id][n].slot;
				}
				return rt(returndata);
				break;
			case "undo-bet":
				if (data.args.length > 2) {
					var delID = parseInt(data.args[2]);
					if (!isNaN(delID)) {
						var olddata = global.data.rouletteData[id][delID - 1];
						if (olddata != undefined) {
							global.data.rouletteData[id].splice(delID - 1, 1);
							var deleted = true;
						} else {
							var deleted = false;
						}
					} else {
						var deleted = false;
					}
					if (deleted) {
						if (!!olddata) {
							OPCODE.add(id, olddata.size, data.args.join(" "));
						}
						return rt(languagePack["ROULETTE_BET_DELETED"].replace("{0}", delID));
					} else {
						return rt(languagePack["ROULETTE_BET_CANNOT_BE_DELETED"].replace("{0}", delID));
					}
				} else {
					return rt(languagePack["ROULETTE_UNKNOWN_ARG"]);
				}
				break;
			case "help":
				switch (type) {
					case "Facebook":
						var imagesx = new global.nodemodule["stream-buffers"].ReadableStreamBuffer({
							frequency: 10,  
							chunkSize: 2048
						});
						imagesx.path = "roulette_help.png";
						imagesx.put(global.fileMap["eco_gambling_roulette_help_picture"]);
						imagesx.stop();
						return {
							handler: "internal-raw",
							data: {
								body: languagePack["ROULETTE_HELP"],
								attachment: imagesx
							}
						}
						break;
					case "Discord":
						return {
							handler: "internal-raw",
							data: {
								files: [global.fileMap["eco_gambling_roulette_help_picture"]],
								body: languagePack["ROULETTE_HELP"]
							}
						}
						break;
					default: 
						break;
				}
				break;
			default:
				return rt(languagePack["ROULETTE_UNKNOWN_ARG"]);
		}
	} else {
		return rt(languagePack["ROULETTE_UNKNOWN_ARG"]);
	}
}

var baicaoFunction = function (type, data) {
	var Economy = global.plugins.economy;
	var { getID, getSymbol, getBalance, validBalance, parseValue, validWallet } = Economy;
	var OPCODE = Economy.operator;
	
	var id = getID(data.msgdata, type);
	validWallet(id);
	
	var rt = function(data) {
		return {
			handler: "internal",
			data: data
		}
	}
	
	if (data.args.length <= 1) {
		return rt(languagePack["TOO_FEW_ARGS"]);
	} else {
		var betsize = Math.abs(parseValue(id, data.args[1]));
		if (isNaN(betsize)) {
			return rt(languagePack["IS_NAN"]);
		} else if (!validBalance(id, betsize)) {
			return rt(languagePack["NOT_ENOUGH_MONEY"]
				.replace("{0}", getBalance(id).floor(2) + getSymbol())
				.replace("{1}", betsize.ceil(2) + getSymbol()));
		} else if (betsize === 0) {
			return rt(languagePack["CANNOT_BET_0"]);
		} else {
			var bobai = [
				"♠A", "♠2", "♠3", "♠4", "♠5", "♠6", "♠7", "♠8", "♠9", "♠X", "♠J", "♠Q", "♠K",
				"♣A", "♣2", "♣3", "♣4", "♣5", "♣6", "♣7", "♣8", "♣9", "♣X", "♣J", "♣Q", "♣K",
				"♦A", "♦2", "♦3", "♦4", "♦5", "♦6", "♦7", "♦8", "♦9", "♦X", "♦J", "♦Q", "♦K",
				"♥A", "♥2", "♥3", "♥4", "♥5", "♥6", "♥7", "♥8", "♥9", "♥X", "♥J", "♥Q", "♥K"
			];
			var nhacai = [];
			var nguoichoi = [];
			var TrueRandom = global.plugins.librandom.MersenneTwister;
			var rndobj = new TrueRandom();
			for (var i = 0; i < 3; i++) {
				nhacai.push(bobai.splice(Math.round(rndobj.random() * bobai.length - 1), 1)[0]);
				nguoichoi.push(bobai.splice(Math.round(rndobj.random() * bobai.length - 1), 1)[0]);
			}
			var totalnguoichoi = 0;
			var totalnhacai = 0;
			var nguoibacaocount = 0;
			var caibacaocount = 0;
			for (var nx in nguoichoi) {
				if (nguoichoi[nx].substr(1) != "J" && nguoichoi[nx].substr(1) != "Q" && nguoichoi[nx].substr(1) != "K" && nguoichoi[nx].substr(1) != "A" && nguoichoi[nx].substr(1) != "X") {
					totalnguoichoi += parseInt(nguoichoi[nx].substr(1));
				} else if (nguoichoi[nx].substr(1) == "A") {
					totalnguoichoi += 1;
				} else {
					totalnguoichoi += 10;
					if (nguoichoi[nx].substr(1) != "X") nguoibacaocount++;
				}
			}
			for (var nx in nhacai) {
				if (nhacai[nx].substr(1) != "J" && nhacai[nx].substr(1) != "Q" && nhacai[nx].substr(1) != "K" && nhacai[nx].substr(1) != "A" && nhacai[nx].substr(1) != "X") {
					totalnhacai += parseInt(nhacai[nx].substr(1));
				} else if (nhacai[nx].substr(1) == "A") {
					totalnhacai += 1;
				} else {
					totalnhacai += 10;
					if (nhacai[nx].substr(1) != "X") caibacaocount++;
				}
			}
			statuser = -1;
			if (totalnguoichoi % 10 == totalnhacai % 10) { statuser = 1; } else if (totalnguoichoi % 10 > totalnhacai % 10) { statuser = 2; } else { statuser = 0; };
			if (nguoibacaocount == 3 && caibacaocount == 3) { statuser = 1; } else if (nguoibacaocount == 3) { statuser = 2; } else if (caibacaocount == 3) { statuser = 0; };
			OPCODE.subtract(id, betsize, data.args.join(" "));
			if (statuser == 1) {
				OPCODE.add(id, betsize, data.args.join(" "));
				return rt(languagePack["BAICAO_DRAW_MESSAGE"]
					.replace("{0}", JSON.stringify(nhacai) + " (" + (totalnhacai % 10) + ")")
					.replace("{1}", JSON.stringify(nguoichoi) + " (" + (totalnguoichoi % 10) + ")"));
			} else if (statuser == 2) {
				OPCODE.add(id, betsize * 2, data.args.join(" "));
				return rt(languagePack["BAICAO_WIN_MESSAGE"]
					.replace("{0}", betsize.floor(2) + getSymbol())
					.replace("{1}", JSON.stringify(nhacai) + " (" + (totalnhacai % 10) + ")")
					.replace("{2}", JSON.stringify(nguoichoi) + " (" + (totalnguoichoi % 10) + ")"));
			} else {
				return rt(languagePack["BAICAO_LOSE_MESSAGE"]
					.replace("{0}", betsize.floor(2) + getSymbol())
					.replace("{1}", JSON.stringify(nhacai) + " (" + (totalnhacai % 10) + ")")
					.replace("{2}", JSON.stringify(nguoichoi) + " (" + (totalnguoichoi % 10) + ")"));
			}
		}
	}
}

var rpsFunction = function (type, data) {
	var Economy = global.plugins.economy;
	var { getID, getSymbol, getBalance, validBalance, parseValue, validWallet } = Economy;
	var OPCODE = Economy.operator;
	
	var id = getID(data.msgdata, type);
	var rt = function(data) {
		return {
			handler: "internal",
			data: data
		}
	}
	if (data.args.length <= 1) {
		return rt(languagePack["TOO_FEW_ARGS"]);
	} else {
		var betsize = Math.abs(parseValue(id, data.args[1]));
		if (isNaN(betsize)) {
			return rt(languagePack["IS_NAN"]);
		} else if (!validBalance(id, betsize)) {
			return rt(languagePack["NOT_ENOUGH_MONEY"].replace("{0}", global.data.economy[id].floor(2) + getSymbol()).replace("{1}", betsize.ceil(2) + getSymbol()));
		} else if (betsize == 0) {
			return rt(languagePack["CANNOT_BET_0"]);
		} else {
			var TrueRandom = global.plugins.librandom.MersenneTwister;
			var rndobj = Math; //new TrueRandom();
			var statuser = -1;
			var rpsp = -1;
			var rpsb = Math.round((new TrueRandom(Math.round(Math.random() * Date.now()))).random() * 2);
			if (typeof data.args[2] != "undefined") {
				switch (data.args[2].substr(0, 1)) {
					case "r":
						rpsp = 0;
						break;
					case "p":
						rpsp = 1;
						break;
					case "s":
						rpsp = 2;
						break;
					default:
						rpsp = Math.round(rndobj.random() * 2); 
				}
			} else {
				rpsp = random(0, 2); 
			}
			switch (rpsp) {
				case 0:
					switch (rpsb) {
						case 0:
							statuser = 1;
							break;
						case 1:
							statuser = 0;
							break;
						case 2:
							statuser = 2;
							break;
					}
					break;
				case 1:
					switch (rpsb) {
						case 1:
							statuser = 1;
							break;
						case 2:
							statuser = 0;
							break;
						case 0:
							statuser = 2;
							break;
					}
					break;
				case 2:
					switch (rpsb) {
						case 2:
							statuser = 1;
							break;
						case 0:
							statuser = 0;
							break;
						case 1:
							statuser = 2;
							break;
					}
					break;
			}
			function resolveMove(rps) {
				switch (rps) {
					case 0:
						return languagePack["RPS_ROCK"];
						break;
					case 1:
						return languagePack["RPS_PAPER"];
						break;
					case 2:
						return languagePack["RPS_SCISSOR"];
						break;
					default:
						return "???";
				}
			}
			OPCODE.subtract(id, betsize, data.args.join(" "));
			if (statuser == 1) {
				OPCODE.add(id, betsize, data.args.join(" ") + " | DRAW");
				return rt(languagePack["RPS_DRAW_MESSAGE"].replace("{0}", resolveMove(rpsb)).replace("{1}", resolveMove(rpsp)));
			} else if (statuser == 2) {
				OPCODE.add(id, betsize * 2, data.args.join(" ") + " | WIN");
				return rt(languagePack["RPS_WIN_MESSAGE"].replace("{0}", Math.abs(betsize).floor(2) + getSymbol()).replace("{1}", resolveMove(rpsb)).replace("{2}", resolveMove(rpsp)));
			} else {
				return rt(languagePack["RPS_LOSE_MESSAGE"].replace("{0}", Math.abs(betsize).floor(2) + getSymbol()).replace("{1}", resolveMove(rpsb)).replace("{2}", resolveMove(rpsp)));
			}
		}
	}
}

/* var blackjackFunction = function blackjackFunction(type, data) {
	var rt = function(data) {
		return {
			handler: "internal",
			data: data
		}
	}
	if (global.data.ecoGambling.blackjack.hasOwnProperty(data.msgdata.senderID)) {
		return {
			handler: "internal",
			data: languagePack["BLACKJACK_ALREADY_RUNNING"]
		}
	} else {
		var betsize = (data.args[1] == "all" ? global.data.economy[id] : (data.args[1] == "half" ? (global.data.economy[id] / 2) : (isNaN(parseFloat(data.args[1])) ? 0 : parseFloat(data.args[1]))));
		if (isNaN(betsize)) return rt(languagePack["IS_NAN"]);
		if (global.data.economy[id] - Math.abs(betsize) < 0) 
			return rt(languagePack["NOT_ENOUGH_MONEY"].replace("{0}", global.data.economy[id]).replace("{1}", Math.abs(betsize)));
		if (Math.abs(betsize) == 0) return rt(languagePack["CANNOT_BET_0"]);
		OPCODE.subtract(id, Math.abs(betsize), data.args.join(" "));
		global.data.ecoGambling.blackjack[data.msgdata.senderID] = {
			amount: Math.abs(betsize),
			dealercard: [],
			playercard: [],
			deck: [
				"♠A", "♠2", "♠3", "♠4", "♠5", "♠6", "♠7", "♠8", "♠9", "♠X", "♠J", "♠Q", "♠K",
				"♣A", "♣2", "♣3", "♣4", "♣5", "♣6", "♣7", "♣8", "♣9", "♣X", "♣J", "♣Q", "♣K",
				"♦A", "♦2", "♦3", "♦4", "♦5", "♦6", "♦7", "♦8", "♦9", "♦X", "♦J", "♦Q", "♦K",
				"♥A", "♥2", "♥3", "♥4", "♥5", "♥6", "♥7", "♥8", "♥9", "♥X", "♥J", "♥Q", "♥K"
			]
		}
		global.data.ecoGambling.blackjack[data.msgdata.senderID].dealercard.push(
			global.data.ecoGambling.blackjack[data.msgdata.senderID].deck.splice(
				random(0, global.data.ecoGambling.blackjack[data.msgdata.senderID].deck.length - 1), 1
			)[0]
		);
		global.data.ecoGambling.blackjack[data.msgdata.senderID].playercard.push(
			global.data.ecoGambling.blackjack[data.msgdata.senderID].deck.splice(
				random(0, global.data.ecoGambling.blackjack[data.msgdata.senderID].deck.length - 1), 1
			)[0]
		);
		global.data.ecoGambling.blackjack[data.msgdata.senderID].dealercard.push(
			global.data.ecoGambling.blackjack[data.msgdata.senderID].deck.splice(
				random(0, global.data.ecoGambling.blackjack[data.msgdata.senderID].deck.length - 1), 1
			)[0]
		);
		global.data.ecoGambling.blackjack[data.msgdata.senderID].playercard.push(
			global.data.ecoGambling.blackjack[data.msgdata.senderID].deck.splice(
				random(0, global.data.ecoGambling.blackjack[data.msgdata.senderID].deck.length - 1), 1
			)[0]
		);
		//Counting
		var count = 0;
		var aces = 0;
		for (var z in global.data.ecoGambling.blackjack[data.msgdata.senderID].playercard) {
			switch (global.data.ecoGambling.blackjack[data.msgdata.senderID].playercard[z][1]) {
				case "X":
				case "J":
				case "Q":
				case "K":
					count += 10;
					break;
				case "A":
					aces++;
					break;
				default: 
					count += parseInt(global.data.ecoGambling.blackjack[data.msgdata.senderID].playercard[z][1]);
			}
		}
		if (aces > 0) {
			for (i = 0; i < aces; i++) {
				if (count + 11 <= 21) {
					count += 11;
				} else {
					count += 1;
				}
			}
		}
		var possiblecommand = ["hit", "stand", "double down", "info"];
		
		//Dealer count
		var dealercount = 0;
		var dealeraces = 0;
		for (var z in global.data.ecoGambling.blackjack[data.msgdata.senderID].dealercard) {
			switch (global.data.ecoGambling.blackjack[data.msgdata.senderID].dealercard[z][1]) {
				case "X":
				case "J":
				case "Q":
				case "K":
					dealercount += 10;
					break;
				case "A":
					dealeraces++;
					break;
				default: 
					count += parseInt(global.data.ecoGambling.blackjack[data.msgdata.senderID].dealercard[z][1]);
			}
		}
		if (dealeraces > 0) {
			for (i = 0; i < dealeraces; i++) {
				if (dealercount + 11 <= 21) {
					dealercount += 11;
				} else {
					dealercount += 1;
				}
			}
		}
		
		return {
			handler: "internal",
			data: languagePack["BLACKJACK_INFO"]
				.replace("{0}", 
					count == 21 
					? JSON.stringify(global.data.ecoGambling.blackjack[data.msgdata.senderID].dealercard)
					: JSON.stringify([global.data.ecoGambling.blackjack[data.msgdata.senderID].dealercard[0], "??"])
				)
				.replace("{1}", count == 21 ? dealercount.toFixed(0) : "?")
				.replace("{2}", JSON.stringify(global.data.ecoGambling.blackjack[data.msgdata.senderID].playercard))
				.replace("{3}", count.toFixed(0))
			+ "\r\n"
			+ (count == 21 ? 
				(function() { 
					delete global.data.ecoGambling.blackjack[data.msgdata.senderID];
					if (dealercount == 21) {
						OPCODE.add(
							id, 
							Math.abs(betsize), 
							data.args.join(" ") + " (Blackjack/21 | Draw)"
						);
						return languagePack["DRAW"];
					}
					OPCODE.add(
						id, 
						Math.abs(betsize) * 2, 
						data.args.join(" ") + " (Blackjack/21)"
					);
					return languagePack["WIN"].replace("{0}", Math.abs(betsize).floor(2));
				})() : 
				languagePack["USE_COMMAND"].replace(
					"{0}", 
					possiblecommand.map(x => x = "`" + x + "`").join(" " + languagePack["OR"] + " ")
				)
			)
			+ "."
		}
	}
}

var chathook = function chathook(type, data) {
	var message = data.msgdata;
	if (data.msgdata.type == "message") {
		if (global.data.ecoGambling.blackjack.hasOwnProperty(data.msgdata.senderID)) {				
			switch (data.msgdata.body) {
				case "hit":
					global.data.ecoGambling.blackjack[data.msgdata.senderID].playercard.push(
						global.data.ecoGambling.blackjack[data.msgdata.senderID].deck.splice(
							random(0, global.data.ecoGambling.blackjack[data.msgdata.senderID].deck.length - 1), 1
						)[0]
					);
					//Counting
					var count = 0;
					var aces = 0;
					for (var z in global.data.ecoGambling.blackjack[data.msgdata.senderID].playercard) {
						switch (global.data.ecoGambling.blackjack[data.msgdata.senderID].playercard[z][1]) {
							case "X":
							case "J":
							case "Q":
							case "K":
								count += 10;
								break;
							case "A":
								aces++;
								break;
							default: 
								count += parseInt(global.data.ecoGambling.blackjack[data.msgdata.senderID].playercard[z][1]);
						}
					}
					if (aces > 0) {
						for (i = 0; i < aces; i++) {
							if (count + 11 <= 21) {
								count += 11;
							} else {
								count += 1;
							}
						}
					}
					var possiblecommand = ["hit", "stand", "info"];
					if (count >= 21) {
						//Dealer count
						var dealercount = 0;
						var dealeraces = 0;
						for (var z in global.data.ecoGambling.blackjack[data.msgdata.senderID].dealercard) {
							switch (global.data.ecoGambling.blackjack[data.msgdata.senderID].dealercard[z][1]) {
								case "X":
								case "J":
								case "Q":
								case "K":
									dealercount += 10;
									break;
								case "A":
									dealeraces++;
									break;
								default: 
									count += parseInt(global.data.ecoGambling.blackjack[data.msgdata.senderID].dealercard[z][1]);
							}
						}
						if (dealeraces > 0) {
							for (i = 0; i < dealeraces; i++) {
								if (dealercount + 11 <= 21) {
									dealercount += 11;
								} else {
									dealercount += 1;
								}
							}
						}
						if (count > 21) {
							data.return({
								handler: "internal",
								data: languagePack["BLACKJACK_INFO"]
									.replace("{0}", JSON.stringify(global.data.ecoGambling.blackjack[data.msgdata.senderID].dealercard))
									.replace("{1}", dealercount.toFixed(0))
									.replace("{2}", JSON.stringify(global.data.ecoGambling.blackjack[data.msgdata.senderID].playercard))
									.replace("{3}", count.toFixed(0))
								+ "\r\n"
								+ languagePack["LOSE"].replace(
									"{0}", 
									global.data.ecoGambling.blackjack[data.msgdata.senderID].amount.floor(2) + getSymbol()
								)
								+ "."
							});
							return true;
						} else {
							if (dealercount == 21) {
								data.return({
									handler: "internal",
									data: languagePack["BLACKJACK_INFO"]
										.replace("{0}", JSON.stringify(global.data.ecoGambling.blackjack[data.msgdata.senderID].dealercard))
										.replace("{1}", dealercount.toFixed(0))
										.replace("{2}", JSON.stringify(global.data.ecoGambling.blackjack[data.msgdata.senderID].playercard))
										.replace("{3}", count.toFixed(0))
									+ "\r\n"
									+ languagePack["DRAW"]
									+ "."
								});
								return true;
							} else {
								data.return(bjPerformBotAI(data.msgdata.senderID));
								return true;
							}
						}
					}
				case "stand":
					data.return(bjPerformBotAI(data.msgdata.senderID));
					return true;
				case "double down":
					global.data.ecoGambling.blackjack[data.msgdata.senderID].amount *= 2;
					data.return(bjPerformBotAI(data.msgdata.senderID));
					return true;
				case "info":
					//Counting
					var count = 0;
					var aces = 0;
					for (var z in global.data.ecoGambling.blackjack[data.msgdata.senderID].playercard) {
						switch (global.data.ecoGambling.blackjack[data.msgdata.senderID].playercard[z][1]) {
							case "X":
							case "J":
							case "Q":
							case "K":
								count += 10;
								break;
							case "A":
								aces++;
								break;
							default: 
								count += parseInt(global.data.ecoGambling.blackjack[data.msgdata.senderID].playercard[z][1]);
						}
					}
					if (aces > 0) {
						for (i = 0; i < aces; i++) {
							if (count + 11 <= 21) {
								count += 11;
							} else {
								count += 1;
							}
						}
					}
					var possiblecommand = ["hit", "stand", "double down", "info"];
					
					//Dealer count
					var dealercount = 0;
					var dealeraces = 0;
					for (var z in global.data.ecoGambling.blackjack[data.msgdata.senderID].dealercard) {
						switch (global.data.ecoGambling.blackjack[data.msgdata.senderID].dealercard[z][1]) {
							case "X":
							case "J":
							case "Q":
							case "K":
								dealercount += 10;
								break;
							case "A":
								dealeraces++;
								break;
							default: 
								count += parseInt(global.data.ecoGambling.blackjack[data.msgdata.senderID].dealercard[z][1]);
						}
					}
					if (dealeraces > 0) {
						for (i = 0; i < dealeraces; i++) {
							if (dealercount + 11 <= 21) {
								dealercount += 11;
							} else {
								dealercount += 1;
							}
						}
					}
					
					data.return({
						handler: "internal",
						data: languagePack["BLACKJACK_INFO"]
							.replace("{0}", 
								count == 21 
								? JSON.stringify(global.data.ecoGambling.blackjack[data.msgdata.senderID].dealercard)
								: JSON.stringify([global.data.ecoGambling.blackjack[data.msgdata.senderID].dealercard[0], "??"])
							)
							.replace("{1}", count == 21 ? dealercount.toFixed(0) : "?")
							.replace("{2}", JSON.stringify(global.data.ecoGambling.blackjack[data.msgdata.senderID].playercard))
							.replace("{3}", count.toFixed(0))
						+ "\r\n"
						+ (count == 21 ? 
							(function() { 
								delete global.data.ecoGambling.blackjack[data.msgdata.senderID];
								if (dealercount == 21) {
									OPCODE.add(
										id, 
										Math.abs(betsize), 
										data.args.join(" ") + " (Blackjack/21 | Draw)"
									);
									return languagePack["DRAW"];
								}
								OPCODE.add(
									id, 
									Math.abs(betsize) * 2, 
									data.args.join(" ") + " (Blackjack/21)"
								);
								return languagePack["WIN"].replace("{0}", Math.abs(betsize).floor(2));
							})() : 
							languagePack["USE_COMMAND"].replace(
								"{0}", 
								possiblecommand.map(x => x = "`" + x + "`").join(" " + languagePack["OR"] + " ")
							)
						)
						+ "."
					});
				default:
					return undefined;
			}
		}
	}
}

//Library
function getSum(numbers, sum) {
    function iter(index, right, left) {
        if (!left) return result.push(right);
        if (left < 0 || index >= numbers.length) return;
        iter(index, [...right, numbers[index]], left - numbers[index]);
        iter(index + 1, right, left);
    }

    var result = [];
    iter(0, [], sum);
    return result;
}

function bjPerformBotAI(id) {
	var data = global.data.ecoGambling.blackjack[id];
	var doDraw = false;
	var cardLeft = {
		"A": 0,
		"X": 0,
		"J": 0,
		"Q": 0,
		"K": 0
	}
	for (i = 2; i <= 9; i++) cardLeft[i.toString()] = 0;
	for (var n in global.data.ecoGambling.blackjack[id].deck) 
		cardLeft[global.data.ecoGambling.blackjack[id].deck[n][1]]++;
	
	var count = 0;
	var aces = 0;
	for (var z in global.data.ecoGambling.blackjack[id].playercard) {
		switch (global.data.ecoGambling.blackjack[id].playercard[z][1]) {
			case "X":
			case "J":
			case "Q":
			case "K":
				count += 10;
				break;
			case "A":
				aces++;
				break;
			default: 
				count += parseInt(global.data.ecoGambling.blackjack[id].playercard[z][1]);
		}
	}
	if (aces > 0) {
		for (i = 0; i < aces; i++) {
			if (count + 11 <= 21) {
				count += 11;
			} else {
				count += 1;
			}
		}
	}
	var dealercount = 0;
	var dealeraces = 0;
	for (var z in global.data.ecoGambling.blackjack[id].dealercard) {
		switch (global.data.ecoGambling.blackjack[id].dealercard[z][1]) {
			case "X":
			case "J":
			case "Q":
			case "K":
				dealercount += 10;
				break;
			case "A":
				dealeraces++;
				break;
			default: 
				count += parseInt(global.data.ecoGambling.blackjack[id].dealercard[z][1]);
		}
	}
	if (dealeraces > 0) {
		for (i = 0; i < dealeraces; i++) {
			if (dealercount + 11 <= 21) {
				dealercount += 11;
			} else {
				dealercount += 1;
			}
		}
	}
	//Get win chance
	var minimumcardget = count - dealercount;
	var maximumcardget = 21 - dealercount;
	if (minimumcardget > maximumcardget) {
		doDraw = Boolean(random(0, 1));
	} else {
		var winchance = 0;
		for (i = minimumcardget; i <= maximumcardget; i++) {
			// if (i == 1 || i == 11) {
				// probwin1times += cardLeft["A"] / global.data.ecoGambling.blackjack[id].deck.length;
			// } else if (i == 10) {
				// probwin1times += cardLeft["X"] / global.data.ecoGambling.blackjack[id].deck.length;
				// probwin1times += cardLeft["J"] / global.data.ecoGambling.blackjack[id].deck.length;
				// probwin1times += cardLeft["Q"] / global.data.ecoGambling.blackjack[id].deck.length;
				// probwin1times += cardLeft["K"] / global.data.ecoGambling.blackjack[id].deck.length;
			// } else if (i >= 2 && i <= 9) {
				// probwin1times += cardLeft[i.toString()] / global.data.ecoGambling.blackjack[id].deck.length;
			// }
			var numberArr = [];
			var numberLeft = {};
			for (z = 1; z <= 10; z++) numberLeft[z] = 0;
			for (var n in cardLeft) {
				if (cardLeft[n] != 0 && !isNaN(parseInt(n))) {
					numberArr.push[parseInt(n)];
					numberLeft[parseInt(n)] += cardLeft[n];
				}
				if (cardLeft[n] != 0 && (n == "X" || n == "J" || n == "Q" || n == "K")) {
					if (numberArr.indexOf(10) == -1) numberArr.push[10];
					numberLeft[10] += cardLeft[n];
				}
				if (cardLeft[n] != 0 && n == "A") {
					numberArr.push[1];
					numberLeft[1] += cardLeft[n];
				}
			}
			var possibleCombination = getSum(numberArr, i).filter(x => x.length <= 3).filter(function (x) {
				var numberRequired = {};
				for (var z = 1; z <= 10; z++) numberLeft[z] = 0;
				for (z in x) numberRequired[x[z]]++;
				var isOK = true;
				for (z in numberRequired) 
					if (numberRequired[z] - numberLeft[z] > 0) 
						isOK = false;
				return isOK;
			});
			possibleCombination.forEach(function (x) {
				x.forEach(function (y) {
					if (y == 10) {
						winchance += cardLeft["X"] / global.data.ecoGambling.blackjack[id].deck.length;
						winchance += cardLeft["J"] / global.data.ecoGambling.blackjack[id].deck.length;
						winchance += cardLeft["Q"] / global.data.ecoGambling.blackjack[id].deck.length;
						winchance += cardLeft["K"] / global.data.ecoGambling.blackjack[id].deck.length;
					} else if (y == 1){
						winchance += cardLeft["A"] / global.data.ecoGambling.blackjack[id].deck.length;
					} else {
						winchance += cardLeft[y.toString()] / global.data.ecoGambling.blackjack[id].deck.length;
					}
				});
			});
		}
		if (winchance >= 0.5) {
			doDraw = true;
		} else {
			doDraw = false;
		}
	}
	while (doDraw) {
		cardLeft[global.data.ecoGambling.blackjack[id].dealercard[
			global.data.ecoGambling.blackjack[id].dealercard.push(
				global.data.ecoGambling.blackjack[id].deck.splice(
					random(0, global.data.ecoGambling.blackjack[id].deck.length - 1), 1
				)[0]
			) - 1
		][1]]--;
		dealercount = 0;
		dealeraces = 0;
		for (var z in global.data.ecoGambling.blackjack[id].dealercard) {
			switch (global.data.ecoGambling.blackjack[id].dealercard[z][1]) {
				case "X":
				case "J":
				case "Q":
				case "K":
					dealercount += 10;
					break;
				case "A":
					dealeraces++;
					break;
				default: 
					count += parseInt(global.data.ecoGambling.blackjack[id].dealercard[z][1]);
			}
		}
		if (dealeraces > 0) {
			for (i = 0; i < dealeraces; i++) {
				if (dealercount + 11 <= 21) {
					dealercount += 11;
				} else {
					dealercount += 1;
				}
			}
		}
		//Get win chance
		minimumcardget = count - dealercount;
		maximumcardget = 21 - dealercount;
		if (minimumcardget > maximumcardget) {
			doDraw = Boolean(random(0, 1));
		} else {
			winchance = 0;
			for (i = minimumcardget; i <= maximumcardget; i++) {
				// if (i == 1 || i == 11) {
					// probwin1times += cardLeft["A"] / global.data.ecoGambling.blackjack[id].deck.length;
				// } else if (i == 10) {
					// probwin1times += cardLeft["X"] / global.data.ecoGambling.blackjack[id].deck.length;
					// probwin1times += cardLeft["J"] / global.data.ecoGambling.blackjack[id].deck.length;
					// probwin1times += cardLeft["Q"] / global.data.ecoGambling.blackjack[id].deck.length;
					// probwin1times += cardLeft["K"] / global.data.ecoGambling.blackjack[id].deck.length;
				// } else if (i >= 2 && i <= 9) {
					// probwin1times += cardLeft[i.toString()] / global.data.ecoGambling.blackjack[id].deck.length;
				// }
				var numberArr = [];
				var numberLeft = {};
				for (z = 1; z <= 10; z++) numberLeft[z] = 0;
				for (var n in cardLeft) {
					if (cardLeft[n] != 0 && !isNaN(parseInt(n))) {
						numberArr.push[parseInt(n)];
						numberLeft[parseInt(n)] += cardLeft[n];
					}
					if (cardLeft[n] != 0 && (n == "X" || n == "J" || n == "Q" || n == "K")) {
						if (numberArr.indexOf(10) == -1) numberArr.push[10];
						numberLeft[10] += cardLeft[n];
					}
					if (cardLeft[n] != 0 && n == "A") {
						numberArr.push[1];
						numberLeft[1] += cardLeft[n];
					}
				}
				var possibleCombination = getSum(numberArr, i).filter(x => x.length <= 3).filter(function (x) {
					var numberRequired = {};
					for (var z = 1; z <= 10; z++) numberLeft[z] = 0;
					for (z in x) numberRequired[x[z]]++;
					var isOK = true;
					for (z in numberRequired) 
						if (numberRequired[z] - numberLeft[z] > 0) 
							isOK = false;
					return isOK;
				});
				possibleCombination.forEach(function (x) {
					x.forEach(function (y) {
						if (y == 10) {
							winchance += cardLeft["X"] / global.data.ecoGambling.blackjack[id].deck.length;
							winchance += cardLeft["J"] / global.data.ecoGambling.blackjack[id].deck.length;
							winchance += cardLeft["Q"] / global.data.ecoGambling.blackjack[id].deck.length;
							winchance += cardLeft["K"] / global.data.ecoGambling.blackjack[id].deck.length;
						} else if (y == 1){
							winchance += cardLeft["A"] / global.data.ecoGambling.blackjack[id].deck.length;
						} else {
							winchance += cardLeft[y.toString()] / global.data.ecoGambling.blackjack[id].deck.length;
						}
					});
				});
			}
			if (winchance >= 0.2) {
				doDraw = true;
			} else {
				doDraw = false;
			}
			if (dealercount >= 21) break;
		}
	}
	if ((dealercount > 21) || (dealercount - count < 0)) {
		OPCODE.add(
			id, 
			Math.abs(global.data.ecoGambling.blackjack[id].amount) * 2, 
			"Blackjack game - Win"
		);
		return {
			handler: "internal",
			data: languagePack["BLACKJACK_INFO"]
				.replace("{0}", JSON.stringify(global.data.ecoGambling.blackjack[id].dealercard))
				.replace("{1}", dealercount.toFixed(0))
				.replace("{2}", JSON.stringify(global.data.ecoGambling.blackjack[id].playercard))
				.replace("{3}", count.toFixed(0))
			+ "\r\n"
			+ languagePack["WIN"].replace(
				"{0}", 
				global.data.ecoGambling.blackjack[id].amount.floor(2) + getSymbol()
			)
			+ "."
		}
	} else if (dealercount == count) {
		OPCODE.add(
			id, 
			Math.abs(global.data.ecoGambling.blackjack[id].amount), 
			"Blackjack game - Draw"
		);
		return {
			handler: "internal",
			data: languagePack["BLACKJACK_INFO"]
				.replace("{0}", JSON.stringify(global.data.ecoGambling.blackjack[id].dealercard))
				.replace("{1}", dealercount.toFixed(0))
				.replace("{2}", JSON.stringify(global.data.ecoGambling.blackjack[id].playercard))
				.replace("{3}", count.toFixed(0))
			+ "\r\n"
			+ languagePack["DRAW"]
			+ "."
		}
	} else if (dealercount - count >= 0) {
		return {
			handler: "internal",
			data: languagePack["BLACKJACK_INFO"]
				.replace("{0}", JSON.stringify(global.data.ecoGambling.blackjack[id].dealercard))
				.replace("{1}", dealercount.toFixed(0))
				.replace("{2}", JSON.stringify(global.data.ecoGambling.blackjack[id].playercard))
				.replace("{3}", count.toFixed(0))
			+ "\r\n"
			+ languagePack["LOSE"].replace(
				"{0}", 
				global.data.ecoGambling.blackjack[id].amount.floor(2) + getSymbol()
			)
			+ "."
		}
	}
} */


module.exports = {
	diceFunction: diceFunction,
	rouletteFunction: rouletteFunction,
	baicaoFunction: baicaoFunction,
	rpsFunction: rpsFunction//,
	//blackjackFunction: blackjackFunction,
	//chathook: chathook
}
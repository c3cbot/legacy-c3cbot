var messages = {
	"vi_VN": [
		"Dự báo thời tiết hôm nay tại",
		"Nhiệt độ",
		"Độ ẩm",
		"Vui lòng nhập thành phố.",
		"Đang chờ gửi toạ độ/vị trí... (thời gian chờ tối đa: 1 phút)",
		"Đã hết thời gian chờ gửi toạ độ/vị trí."
	],
	"en_US": [
		"Today's weather forecast for",
		"Temperature",
		"Humidity",
		"Please enter city.",
		"Waiting for coordinates/location... (maximum waiting time: 1 minute)",
		"Timed out waiting for coordinates/location."
	]
}

var fs = require("fs");
var query = require("querystring");
var url = require("url");
var fetch = global.nodemodule["node-fetch"];
var path = require("path");

/**
 * Ensure <path> exists.
 *
 * @param   {string}  path  Path
 * @param   {number}  mask  Folder's mask
 *
 * @return  {object}        Error or nothing.
 */
function ensureExists(path, mask) {
  if (typeof mask != 'number') {
    mask = 0o777;
  }
  try {
    fs.mkdirSync(path, {
      mode: mask,
      recursive: true
    });
    return undefined;
  } catch (ex) {
    return { err: ex };
  }
}

var current = 0;
ensureExists(path.join(__dirname, "..", "Weather"));
var defaultConfig = {
	help1: 'EDIT THE OPENWEATHERMAP API KEYS: ["api key 1", "api key 2"]',
	help2: 'LEAVING API KEYS AS AN EMPTY ARRAY WILL RESULT IN ERROR!',
	apiKeys: ["d4e144676bd7c0e0c3c3897ff9708da9"]
}
if (!fs.existsSync(path.join(__dirname, "..", "Weather", "config.json"))) {
	fs.writeFileSync(path.join(__dirname, "..", "Weather", "config.json"), JSON.stringify(defaultConfig, null, 4));
	var config = defaultConfig;
} else {
	var config = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "Weather", "config.json"), {
		encoding: "utf8"
	}));
	if (config.apiKeys.length == 0) {
		config.apiKeys = ["d4e144676bd7c0e0c3c3897ff9708da9"];
	}
}

var getLocation = function getLocation(uri) {
    var u = decodeURIComponent(String(url.parse(uri, true).query["u"]));
    var loc = String(url.parse(u, true).query["where1"]).replace(/ /g, "").split(",");
    return loc.length != 2 ? null : loc;
}

var waiting = {};

var chathook = function(type, datas){
	if (datas.msgdata.type == "message" || datas.msgdata.type == "message_reply") {
		if (typeof waiting[datas.msgdata.senderID] != "undefined") {
			var atts = datas.msgdata.attachments;
			if (atts.length > 0){
				var rt = false;
				var att = null;
				for (var n in atts) {
					att = atts[n];
					//console.log(att);
					if (att.target['__typename'] === "MessageLocation" || att.target['__typename'] === "MessageLiveLocation") {
						rt = true;
						var location = getLocation(att.url);
						var language = "";
						switch (global.config.language.toLocaleLowerCase()) {
							case "zh_cn":
							case "zh_tw": 
							case "pt_br":
								language = global.config.language.toLocaleLowerCase();
							default: 
								language = global.config.language.substr(0, 2).toLocaleLowerCase();
						}
						fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${location[0]}&lon=${location[1]}&units=metric&appid=${config.apiKeys[current % config.apiKeys.length]}&lang=${language}`)
							.then(f => {
								if (f.ok) {
									return f.json();
								} else {
									throw new Error(`Cannot request to OpenWeatherMap with key ${current % config.apiKeys.length}: HTTP/1.1 ${f.status}`);
								}
							})
							.then(data => {
								datas.return({
									handler: "internal",
									data: `${messages[global.config.language][0]} ${data.name}:\n- ${data.weather[0].description[0].toLocaleUpperCase()}${data.weather[0].description.substr(1)}\n- ${messages[global.config.language][1]}: ${data.main.temp_min}°C => ${data.main.temp_max}°C\n- ${messages[global.config.language][2]}: ${data.main.humidity}%`
								});
								try {
									clearTimeout(waiting[datas.msgdata.senderID]);
								} catch (ex) {}
								delete waiting[datas.msgdata.senderID];
							})
							.catch(ex => {
								datas.log("Error:", ex);
								current++;
								if (current / config.apiKeys.length == 2) {
									current = 0;
									return datas.return({
										handler: "internal",
										data: `Couldn't get weather data: ${ex}`
									});
								}
								datas.log("Trying the next keys...");
								return weather(type, datas);
							});	
					}
				};
				return rt;
			}
		}
	}
    return false;
};

var weather = function (type, datas) {
	var location = datas.args.slice(1).join(" ").toLocaleLowerCase();
	if (location === "") 
		if (type === "Facebook") {
			if (typeof waiting[datas.msgdata.senderID] != "undefined") {
				try {
					clearTimeout(waiting[datas.msgdata.senderID]);
				} catch (ex) {}
			}
			waiting[datas.msgdata.senderID] = setTimeout(function (data) {
				data.return({
					handler: "internal",
					data: messages[global.config.language][5]
				});
				try {
					clearTimeout(waiting[data.msgdata.senderID]);
				} catch (ex) {};
				delete waiting[data.msgdata.senderID];
			}, 120000, datas);
			return {
				handler: "internal",
				data: messages[global.config.language][4]
			}
		} else {
			return {
				handler: "internal",
				data: messages[global.config.language][3]
			}
		}
	
	var language = "";
	switch (global.config.language.toLocaleLowerCase()) {
		case "zh_cn":
		case "zh_tw": 
		case "pt_br":
			language = global.config.language.toLocaleLowerCase();
		default: 
			language = global.config.language.substr(0, 2).toLocaleLowerCase();
	}
	fetch(`https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(location)}&units=metric&appid=${config.apiKeys[current % config.apiKeys.length]}&lang=${language}`)
		.then(f => {
			if (f.ok) {
				return f.json();
			} else {
				throw new Error(`Cannot request to OpenWeatherMap with key ${current % config.apiKeys.length}: HTTP/1.1 ${f.status}`);
			}
		})
		.then(data => {
			datas.return({
				handler: "internal",
				data: `${messages[global.config.language][0]} ${data.name}:\n- ${data.weather[0].description[0].toLocaleUpperCase()}${data.weather[0].description.substr(1)}\n- ${messages[global.config.language][1]}: ${data.main.temp_min}°C => ${data.main.temp_max}°C\n- ${messages[global.config.language][2]}: ${data.main.humidity}%`
			});
			try {
				clearTimeout(waiting[datas.msgdata.senderID]);
			} catch (ex) {}
			delete waiting[datas.msgdata.senderID];
		})
		.catch(ex => {
			datas.log("Error:", ex);
			current++;
			if (current / config.apiKeys.length == 2) {
				current = 0;
				return datas.return({
					handler: "internal",
					data: `Couldn't get weather data: ${ex}`
				});
			}
			datas.log("Trying the next keys...");
			return weather(type, datas);
		});	
}

module.exports = {
    weather,
	chathook
};

var messages = {
	"vi_VN": [
		"Dự báo thời tiết hôm nay tại",
		"Nhiệt độ",
		"Độ ẩm",
		"Vui lòng nhập thành phố.",
		"Đang chờ gửi toạ độ/vị trí... (thời gian chờ tối đa: 1 phút)",
		"Đã hết thời gian chờ gửi toạ độ/vị trí."
	],
	"en_US": [
		"Today's weather forecast for",
		"Temperature",
		"Humidity",
		"Please enter city.",
		"Waiting for coordinates/location... (maximum waiting time: 1 minute)",
		"Timed out waiting for coordinates/location."
	]
}

var fs = require("fs");
var query = require("querystring");
var url = require("url");
var fetch = global.nodemodule["node-fetch"];
var path = require("path");

/**
 * Ensure <path> exists.
 *
 * @param   {string}  path  Path
 * @param   {number}  mask  Folder's mask
 *
 * @return  {object}        Error or nothing.
 */
function ensureExists(path, mask) {
  if (typeof mask != 'number') {
    mask = 0o777;
  }
  try {
    fs.mkdirSync(path, {
      mode: mask,
      recursive: true
    });
    return undefined;
  } catch (ex) {
    return { err: ex };
  }
}

var key = "";
var current = 0;
ensureExists(path.join(__dirname, "..", "Weather"));
var defaultConfig = {
	help1: 'EDIT THE OPENWEATHERMAP API KEYS: ["api key 1", "api key 2"]',
	help2: 'LEAVING API KEYS AS AN EMPTY ARRAY WILL RESULT IN ERROR!',
	apiKeys: ["d4e144676bd7c0e0c3c3897ff9708da9"]
}
if (!fs.existsSync(path.join(__dirname, "..", "Weather", "config.json"))) {
	fs.writeFileSync(path.join(__dirname, "..", "Weather", "config.json"), JSON.stringify(defaultConfig, null, 4));
	var config = defaultConfig;
} else {
	var config = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "Weather", "config.json"), {
		encoding: "utf8"
	}));
	if (config.apiKeys.length == 0) {
		config.apiKeys = ["d4e144676bd7c0e0c3c3897ff9708da9"];
	}
}

var getLocation = function getLocation(uri) {
    var u = decodeURIComponent(String(url.parse(uri, true).query["u"]));
    var loc = String(url.parse(u, true).query["where1"]).replace(/ /g, "").split(",");
    return loc.length != 2 ? null : loc;
}

var waiting = {};

var chathook = function(type, datas){
	if (datas.msgdata.type == "message" || datas.msgdata.type == "message_reply") {
		if (typeof waiting[datas.msgdata.senderID] != "undefined") {
			var atts = datas.msgdata.attachments;
			if (atts.length > 0){
				var rt = false;
				var att = null;
				for (var n in atts) {
					att = atts[n];
					console.log(att);
					if (att.target['__typename'] === "MessageLocation") {
						rt = true;
						var location = getLocation(att.url);
						var language = "";
						switch (global.config.language.toLocaleLowerCase()) {
							case "zh_cn":
							case "zh_tw": 
							case "pt_br":
								language = global.config.language.toLocaleLowerCase();
							default: 
								language = global.config.language.substr(0, 2).toLocaleLowerCase();
						}
						fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${location[0]}&lon=${location[1]}&units=metric&appid=${config.apiKeys[current]}&lang=${language}`)
							.then(f => {
								if (f.ok) {
									return f.json();
								} else {
									throw new Error(`Cannot request to OpenWeatherMap with key ${current}`);
								}
							})
							.then(data => {
								datas.return({
									handler: "internal",
									data: `${messages[global.config.language][0]} ${data.name}:\n- ${data.weather[0].description[0].toLocaleUpperCase()}${data.weather[0].description.substr(1)}\n- ${messages[global.config.language][1]}: ${data.main.temp_min}°C => ${data.main.temp_max}°C\n- ${messages[global.config.language][2]}: ${data.main.humidity}%`
								});
								try {
									clearTimeout(waiting[datas.msgdata.senderID]);
								} catch (ex) {}
								delete waiting[datas.msgdata.senderID];
							})
							.catch(ex => {
								datas.log("Error:", ex);
								datas.log("Trying the next keys...");
								current++;
								if (current == config.apiKeys.length) current = 0;
								chathook(type, datas);
							});	
					}
				};
				return rt;
			}
		}
	}
    return false;
};

var looped = false;
var weather = function (type, datas) {
	var location = datas.args.slice(1).join(" ").toLocaleLowerCase();
	if (location === "") 
		if (type === "Facebook") {
			if (typeof waiting[datas.msgdata.senderID] != "undefined") {
				try {
					clearTimeout(waiting[datas.msgdata.senderID]);
				} catch (ex) {}
			}
			waiting[datas.msgdata.senderID] = setTimeout(function (data) {
				data.return({
					handler: "internal",
					data: messages[global.config.language][5]
				});
				try {
					clearTimeout(waiting[data.msgdata.senderID]);
				} catch (ex) {};
				delete waiting[data.msgdata.senderID];
			}, 120000, datas);
			return {
				handler: "internal",
				data: messages[global.config.language][4]
			}
		} else {
			return {
				handler: "internal",
				data: messages[global.config.language][3]
			}
		}
	
	var language = "";
	switch (global.config.language.toLocaleLowerCase()) {
		case "zh_cn":
		case "zh_tw": 
		case "pt_br":
			language = global.config.language.toLocaleLowerCase();
		default: 
			language = global.config.language.substr(0, 2).toLocaleLowerCase();
	}
	fetch(`https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(location)}&units=metric&appid=${config.apiKeys[current]}&lang=${language}`)
		.then(f => {
			if (f.ok) {
				return f.json();
			} else {
				throw new Error(`Cannot request to OpenWeatherMap with key ${current}`);
			}
		})
		.then(data => {
			datas.return({
				handler: "internal",
				data: `${messages[global.config.language][0]} ${data.name}:\n- ${data.weather[0].description[0].toLocaleUpperCase()}${data.weather[0].description.substr(1)}\n- ${messages[global.config.language][1]}: ${data.main.temp_min}°C => ${data.main.temp_max}°C\n- ${messages[global.config.language][2]}: ${data.main.humidity}%`
			});
			try {
				clearTimeout(waiting[datas.msgdata.senderID]);
			} catch (ex) {}
			delete waiting[datas.msgdata.senderID];
		})
		.catch(ex => {
			datas.log("Error:", ex);
			datas.log("Trying the next keys...");
			current++;
			if (current >= config.apiKeys.length && !looped) {
				current = 0;
				looped = true;
				return weather(type, datas);
			} else {
				datas.return({
					handler: "internal",
					data: `Couldn't get weather data: ${ex}`
				});
				current = 0;
				looped = false;
			}
		});	
}

// var weather = function(type, datas){
    // var args = JSON.parse(JSON.stringify(datas.args));
    // args.splice(0, 1);
    // var location = args.join(" ");
    // var location2 = location.toLowerCase();
    // if(location === '') return {handler: "internal",
        // data: "Vui lòng nhập nơi bạn muốn tra cứu."};
    // if(location2 === 'hồ chí minh'||location2 === 'sài gòn'){
        // location2 = 'Ho Chi Minh';
    // }
    // if(location2 === 'úc'){
       // location2 = 'australia';
    // }
    // if(location2 === 'mỹ'){
       // location2 = 'Hoa Kỳ';
    // }
    // if(location2 === 'áo'){
      // location2 = 'Austria';
    // }
    // if(location2 === 'trung quốc'){
      // location2 = 'China';
    // }
    // if(location2 === 'korea'||location2 === 'korean'||location2 === 'south korea'||location2 === 'south korean'||location2 === 'hàn quốc'){
      // location2 = 'Seoul';
    // }
    // if(location2 === 'triều tiên'||location2 === 'north korean'||location2 === 'north korea'){
      // location2 ='Bình Nhưỡng';
    // }
    // var key = "37437d4af251ada5d2508d228953edb6";
    // if(key === "") return {handler: "internal",
        // data: "Xin lỗi, KEY API trống."};
    // var data = JSON.parse(global.nodemodule['sync-request']("GET", "https://api.openweathermap.org/data/2.5/weather?q=" + encodeURIComponent(location2) + "&units=metric&lang=vi&appid=" + encodeURIComponent(key)).body.toString());
// decodeURIComponent();
    // if(data.cod === '404'){
        // return {
            // handler: "internal",
            // data: "Xin lỗi, mình không thể tìm thấy vị trí này."
        // };
    // }else if(data.cod === 200){
      // var cc = String(cities[formatout(data.name)]);
      // var thoitiet = data.weather[0].description.toUpperCase();
      // if(cc === 'undefined') cc = data.name;
      // var img = global.nodemodule['sync-request']("GET", "http://openweathermap.org/img/w/" + data.weather[0].icon + ".png").body;
      // var imagesx = new global.nodemodule["stream-buffers"].ReadableStreamBuffer({
          // frequency: 10,
          // chunkSize: 16
      // });
      // imagesx.path = "img.png";
      // imagesx.put(img);
      // imagesx.stop();
        // var str = "\n• Thời tiết hiện tại của " + cc + ", " + data.sys.country +"\n• " + thoitiet + "\n• Nhiệt độ: " + data.main.temp + "\n• Nhiệt độ trung bình: " + data.main.temp_min + "-" + data.main.temp_max + "°C\n• Độ ẩm: " + data.main.humidity + "%\n• Tốc độ gió: " + data.wind.speed + "m/s";
        // return {
            // handler: "internal-raw",
            // data: {
                // body: str,
                // attachment: ([imagesx])
            // }
        // };
    // }else{
        // return {
            // handler: "internal",
            // data: "Xin lỗi, đã có lỗi trong quá trình thực hiện!"
        // };
    // }
// };

module.exports = {
    weather,
	chathook
};

!global.data.economy ? global.data.economy = {} : "";
!global.data.economyStart ? global.data.economyStart = 0 : "";
!global.data.economyTX ? global.data.economyTX = [] : "";

var sizeObject = function(object) {
	return Object.keys(object).length;
};

var random = function(min, max) { 
	if (min > max) {
		var temp = min;
		min = max;
		max = temp;
	}
	var bnum = (max - min).toString(16).length / 2;
	if (bnum < 1) bnum = 1;
	return Math.round(parseInt(global.nodemodule.crypto.randomBytes(bnum).toString('hex'), 16) / Math.pow(16, bnum * 2) * (max - min)) + min; 
};

var balfunc = function (type, data) {
	var sortable = [];
	for (var userID in global.data.economy) {
		sortable.push([userID, global.data.economy[userID]]);
	}
	var sx = sortable.sort(function(a, b) {
		return b[1] - a[1];
	}).map(x => x[0]);
	var rank = 0;
	
	if (sizeObject(data.mentions)) {
		var retval = "";
		for (var y in data.mentions) {
			var id = y;
			var balance = getbalance(id);
			var symbol = getSymbol();
			var cname = global.data.cacheName[id];
			var rank = sx.indexOf(id) + 1;
		
			retval += `${cname} - ${balance.floor(2)}${symbol} (#${rank})`;
		} 
		return {
			handler: "internal",
			data: retval
		}
	} else {
		var id = getID(data.msgdata, type);
		var balance = getbalance(id);
		var symbol = getSymbol();
		var cname = global.data.cacheName[id];
		var rank = sx.indexOf(id) + 1;
		return {
			handler: "internal",
			data: `${cname} - ${balance.floor(2)}${symbol} (#${rank})`
		}
	}
}

var baltopfunc = function (type, data) {
	var balsorted = [];
	for (var userID in global.data.economy) {
		balsorted.push([userID, global.data.economy[userID]]);
	}
	balsorted = balsorted.sort(function(a, b) {
		return b[1] - a[1];
	});
	var hs = 'BALANCE TOP: '; 
	var page = parseInt(data.args[1]) || 1; 
	if (page < 1) page = 1; 
	var mentionobj = [];
	if (type == "Discord") {
		hs += "\r\n```HTTP"
	}
	for (i = 10 * (page - 1); i < 10 * (page - 1) + 10; i++) { 
		if (i < balsorted.length) { 
			//hs += "\r\n" + (i + 1) + ". " + (global.data.cacheName[balsorted[i][0]]) + ": " + balsorted[i][1].floor(2) + getSymbol();
			hs += `\r\n${i + 1}. ${global.data.cacheName[balsorted[i][0]]}: ${balsorted[i][1].floor(2)}${getSymbol()}`;
			if (type == "Facebook" && balsorted[i][0].substr(0, 2) == "FB") {
				mentionobj.push({
					tag: String(global.data.cacheName[balsorted[i][0]]),
					id: balsorted[i][0].substr(3),
					fromIndex: hs.match(new RegExp(String(global.data.cacheName[balsorted[i][0]]), "g")).length - 1
				});
			}
		} 
	}; 
	if (type == "Discord") {
		hs += "\r\n```"
	}
	hs += '\r\n(Page ' + page + '/' + (balsorted.length / 10).floor() + ')'; 
	var dataobj = {};
	dataobj.body = hs;
	if (type == "Facebook") {
		dataobj.mentions = mentionobj;
	}
	//data.log(dataobj);
	return {
		handler: "internal-raw",
		data: dataobj
	}
}

var safeadd = function(id, value, reason) {
	validWallet(id);
	(typeof reason != "string") ? reason = "" : "";
	global.data.economyTX.push({
		affectedID: id,
		operation: "add",
		value: value,
		reason: reason,
		oldbalance: global.data.economy[id],
		newbalance: (global.data.economy[id] + value)
	});
	global.data.economy[id] += value;
}

var safesubtract = function(id, value, reason) {
	validWallet(id);
	(typeof reason != "string") ? reason = "" : "";
	global.data.economyTX.push({
		affectedID: id,
		operation: "subtract",
		value: value,
		reason: reason,
		oldbalance: global.data.economy[id],
		newbalance: (global.data.economy[id] - value)
	});
	global.data.economy[id] -= value;	
}

var safemultiply = function(id, value, reason) {
	validWallet(id);
	(typeof reason != "string") ? reason = "" : "";
	global.data.economyTX.push({
		affectedID: id,
		operation: "multiply",
		value: value,
		reason: reason,
		oldbalance: global.data.economy[id],
		newbalance: (global.data.economy[id] * value)
	});
	global.data.economy[id] *= value;
}

var safedivine = function(id, value, reason) {
	validWallet(id);
	(typeof reason != "string") ? reason = "" : "";
	global.data.economyTX.push({
		affectedID: id,
		operation: "divine",
		value: value,
		reason: reason,
		oldbalance: global.data.economy[id],
		newbalance: (global.data.economy[id] / value)
	});
	global.data.economy[id] /= value;
}

var safeset = function(id, value, reason) {
	validWallet(id);
	(typeof reason != "string") ? reason = "" : "";
	global.data.economyTX.push({
		affectedID: id,
		operation: "set",
		value: value,
		reason: reason,
		oldbalance: global.data.economy[id],
		newbalance: value
	});
	global.data.economy[id] = value;
}

var safereset = function(id, value, reason) {
	validWallet(id);
	(typeof reason != "string") ? reason = "" : "";
	global.data.economyTX.push({
		affectedID: id,
		operation: "reset",
		value: global.data.economyStart,
		reason: reason,
		oldbalance: global.data.economy[id],
		newbalance: global.data.economyStart
	});
	global.data.economy[id] = global.data.economyStart;
}

var transferfunc = function (type, data) {
	var args = data.args;
	var id = getID(data.msgdata, type);
	if (args.length > 2 && sizeObject(data.mentions) > 0) {
		var value = Math.abs(parseValue(id, args[1]));
		if (!validBalance(id, value * sizeObject(data.mentions))) {
			return {
				handler: "internal",
				data: "Not enough money!"
			}
		} else {
			var txcode = random(100000000, 999999999);
			var rtdata = "";
			safesubtract(id, value * sizeObject(data.mentions), "Transfer code " + txcode);
			for (var y in data.mentions) {
				safeadd(y, value, "Transfer code " + txcode);
				rtdata == "" 
					? rtdata = `Successfully transferred ${value.floor(2)}${getSymbol()} to ${y}!`
					: rtdata += `\r\nSuccessfully transferred ${value.floor(2)}${getSymbol()} to ${y}!`;
			}
			return {
				handler: "internal",
				data: rtdata
			}
		}
	} else {
		return {
			handler: "internal",
			data: "Unknown parameter!"
		}
	}
}

var unsafetransferfunc = function (type, data) {
	var args = data.args;
	var id = getID(data.msgdata, type);
	if (args.length > 2) {
		var value = Math.abs(parseValue(id, args[1]));
		if (!validBalance(id, value)) {
			return {
				handler: "internal",
				data: "Not enough money!"
			}
		} else {
			var y = args[2];
			var txcode = random(100000000, 999999999);
			safesubtract(id, value, "Transfer code " + txcode);
			safeadd(y, value, "Transfer code " + txcode);
			return {
				handler: "internal",
				data: `Successfully transferred ${value.floor(2)}${getSymbol()} to ${y}!`
			}
		}
	} else {
		return {
			handler: "internal",
			data: "Unknown parameter!"
		}
	}
}

var getunsafewalletcode = function (type, data) {
	var id = getID(data.msgdata, type);
	validWallet(id);
	return {
		handler: "internal",
		data: "Your wallet code is \"" + id + "\". Others can use this wallet code to transfer funds to you."
	}
}

var getbalance = function (id) {
	validWallet(id);
	return global.data.economy[id];
}

var getID = function (msgdata, type) {
	var id = "0";
	switch (type) {
		case "Facebook":
			id = "FB-" + msgdata.senderID;
			break;
		case "Discord":
			id = "DC-" + msgdata.author.id;
			break;
	}
	validWallet(id);
	return id;
}

var getSymbol = function() {
	return "Ƀ";
}

var validWallet = function (id) {
	if (typeof global.data.economy[id] != "number" || isNaN(global.data.economy[id])) {
		global.data.economy[id] = global.data.economyStart;
	}
}

var parseValue = function (id, value) {
	validWallet(id);
	switch (typeof value) {
		case "string":
			switch (value) {
				case "all":
					return parseValue(id, getbalance(id));
				case "half":
					return parseValue(id, getbalance(id) / 2);
				default:
					if (value.endsWith("%")) {
						var percentage = parseFloat(value.substr(0, value.length - 1));
						if (isNaN(percentage)) {
							return 0;
						} else {
							return parseValue(id, getbalance(id) / 100 * percentage);
						}
					} else {
						return parseValue(id, parseFloat(value));
					}
			}
		case "number": 
			if (isNaN(value)) {
				return 0;
			} else {
				return value;
			}
		default:
			return 0;
	}
}

var validBalance = function (id, value) {
	validWallet(id);
	return ((getbalance(id) - parseValue(id, value)) >= 0);
}

module.exports = {
	balfunc: balfunc,
	baltopfunc: baltopfunc,
	transferfunc: transferfunc,
	unsafetransferfunc: unsafetransferfunc,
	getunsafewalletcode: getunsafewalletcode,
	operator: {
		add: safeadd,
		subtract: safesubtract,
		multiply: safemultiply,
		divine: safedivine,
		set: safeset,
		reset: safereset,
		get: getbalance
	},
	getID: getID,
	getSymbol: getSymbol,
	getBalance: getbalance,
	validBalance: validBalance,
	parseValue: parseValue,
	validWallet: validWallet
}
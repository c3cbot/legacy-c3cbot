// Economy 1.x - UIRI 2020

var langMap = {
	"vi_VN": {
		"h.baltop": "Bảng xếp hạng về độ giàu có:",
		"page": "Trang",
		"transfered": "Đã chuyển {0}{1} tới {2}.",
		"nmoney": "Không đủ tiền!",
		"uargs": "Tham số không rõ.",
		"wcode": "Mã ví của bạn: {0}"
	},
	"en_US": {
		"h.baltop": "Balance top:",
		"page": "Page",
		"transfered": "Transfered {0}{1} to {2}.",
		"nmoney": "Not enough money!",
		"uargs": "Unknown parameters.",
		"wcode": "Your wallet code: {0}"
	}
}

var getLang = () => {};

function onLoad(data) {
	let log = data.log;
	getLang = function getLang(langVal, oLang) {
	    var lang = oLang;
	    if (!langMap[lang]) {
		    log("[INTERNAL]", "Warning: Invalid language: ", lang, `; using ${global.config.language} as fallback...`);
		    lang = global.config.language;
	    }

	    if (langMap[lang] && langMap[lang][langVal]) {
	    	return String(langMap[lang][langVal]);
	    } else {
	    	log("[INTERNAL]", "Warning: Invalid language: ", lang, "; using en_US as fallback...");
	    	return String((langMap["en_US"] || {})[langVal]);
	    }
	}
}

/**
 * Get the type of arg
 *
 * @param   {any}    arg  arg
 *
 * @return  {string}      String/Number/Object/Array/Function/AsyncFunction/Null/Undefined/BigInt
 */
let getType = function getType(arg) {
  return Object.prototype.toString.call(arg).slice(8, -1);
}

if (getType(global.data.economy) != "Object") global.data.economy = {};
switch (getType(global.data.economyStart)) {
	case "Number":
		global.data.economyStart = BigInt((global.data.economyStart * (10 ** 8)).round());
		break;
	case "BigInt":
		break;
	case "String":
		try {
			global.data.economyStart = BigInt((global.data.economyStart * (10 ** 8)).round());
		} catch (ex) {
			global.data.economyStart = 0n;
		}
		break;
	default:
		global.data.economyStart = 0n;
}
if (getType(global.data.economyTX) != "Array") global.data.economyTX = [];

//Upgrade. People, upgrade. (0.x Number => 1.x BigInt)
for (let id in global.data.economy) {
	if (typeof global.data.economy[id] == "number") global.data.economy[id] = BigInt((global.data.economy[id] * (10 ** 8)).round());
	if (typeof global.data.economy[id] != "bigint") delete global.data.economy[id]
}

var sizeObject = function(object) {
	return Object.keys(object).length;
};

var random = function(min, max) { 
	if (min > max) {
		var temp = min;
		min = max;
		max = temp;
	}
	var bnum = (max - min).toString(16).length / 2;
	if (bnum < 1) bnum = 1;
	return Math.round(parseInt(global.nodemodule.crypto.randomBytes(bnum).toString('hex'), 16) / Math.pow(16, bnum * 2) * (max - min)) + min; 
};

var balfunc = function (type, data) {
	var sortable = Object.entries(global.data.economy);
	var sx = sortable.sort(function(a, b) {
		return Number(b[1] - a[1]);
	}).map(x => x[0]);
	var rank = 0;
	
	if (sizeObject(data.mentions)) {
		var retval = "";
		for (var y in data.mentions) {
			var id = y;
			var balance = getbalance(id);
			var symbol = getSymbol();
			var cname = global.data.cacheName[id];
			var rank = sx.indexOf(id) + 1;
		
			retval += `${cname} - ${balance.floor(2)}${symbol} (#${rank})`;
		} 
		return {
			handler: "internal",
			data: retval
		}
	} else {
		var id = getID(data.msgdata, type);
		var balance = getbalance(id);
		var symbol = getSymbol();
		var cname = global.data.cacheName[id];
		var rank = sx.indexOf(id) + 1;
		return {
			handler: "internal",
			data: `${cname} - ${balance.floor(2)}${symbol} (#${rank})`
		}
	}
}

var baltopfunc = function (type, data) {
	var sortable = Object.entries(global.data.economy);
	var sx = sortable.sort(function(a, b) {
		return Number(b[1] - a[1]);
	});
	let balsorted = sortable;
	
	var hs = getLang("h.baltop", data.resolvedLang); 
	var page = parseInt(data.args[1]) || 1; 
	if (page < 1) page = 1; 
	var mentionobj = [];
	if (type == "Discord") {
		hs += "\r\n```HTTP"
	}
	for (i = 10 * (page - 1); i < 10 * (page - 1) + 10; i++) { 
		if (i < balsorted.length) { 
			hs += `\r\n${i + 1}. ${global.data.cacheName[balsorted[i][0]]}: ${(Number(balsorted[i][1]) / (10 ** 8)).floor(2)}${getSymbol()}`;
			if (type == "Facebook" && balsorted[i][0].substr(0, 2) == "FB") {
				mentionobj.push({
					tag: String(global.data.cacheName[balsorted[i][0]]),
					id: balsorted[i][0].substr(3),
					fromIndex: hs.match(new RegExp(String(global.data.cacheName[balsorted[i][0]]), "g")).length - 1
				});
			}
		} 
	}; 
	if (type == "Discord") {
		hs += "\r\n```"
	}
	hs += `\r\n(${getLang("page", data.resolvedLang)} ${page}/${(balsorted.length / 10).floor()})`; 
	var dataobj = {};
	dataobj.body = hs;
	if (type == "Facebook") {
		dataobj.mentions = mentionobj;
	}
	//data.log(dataobj);
	return {
		handler: "internal-raw",
		data: dataobj
	}
}

var safeadd = function(id, value, reason) {
	validWallet(id);
	(typeof reason != "string") ? reason = "" : "";
	if (typeof value == "number") {
		value = BigInt((value * (10 ** 8)).round());
	} 
	if (typeof value != "bigint") throw new Error("Value must be a number or BigInt");
	global.data.economyTX.push({
		affectedID: id,
		operation: "add",
		value: value,
		reason: reason,
		oldbalance: global.data.economy[id],
		newbalance: (global.data.economy[id] + value)
	});
	global.data.economy[id] += value;
}

var safesubtract = function(id, value, reason) {
	validWallet(id);
	(typeof reason != "string") ? reason = "" : "";
	if (typeof value == "number") {
		value = BigInt((value * (10 ** 8)).round());
	} 
	if (typeof value != "bigint") throw new Error("Value must be a number or BigInt");
	global.data.economyTX.push({
		affectedID: id,
		operation: "subtract",
		value: value,
		reason: reason,
		oldbalance: global.data.economy[id],
		newbalance: (global.data.economy[id] - value)
	});
	global.data.economy[id] -= value;	
}

var safemultiply = function(id, value, reason) {
	validWallet(id);
	(typeof reason != "string") ? reason = "" : "";
	if (typeof value == "number") {
		value = BigInt((value * (10 ** 8)).round());
	} 
	if (typeof value != "bigint") throw new Error("Value must be a number or BigInt");
	global.data.economyTX.push({
		affectedID: id,
		operation: "multiply",
		value: value,
		reason: reason,
		oldbalance: global.data.economy[id],
		newbalance: (global.data.economy[id] * value)
	});
	global.data.economy[id] *= value;	
}

var safedivide = function(id, value, reason) {
	validWallet(id);
	(typeof reason != "string") ? reason = "" : "";
	if (typeof value == "number") {
		value = BigInt((value * (10 ** 8)).round());
	} 
	if (typeof value != "bigint") throw new Error("Value must be a number or BigInt");
	if (value == 0n) throw new Error("Divide by zero");
	global.data.economyTX.push({
		affectedID: id,
		operation: "divide",
		value: value,
		reason: reason,
		oldbalance: global.data.economy[id],
		newbalance: (global.data.economy[id] / value)
	});
	global.data.economy[id] /= value;
}

var safeset = function(id, value, reason) {
	validWallet(id);
	(typeof reason != "string") ? reason = "" : "";
	if (typeof value == "number") {
		value = BigInt((value * (10 ** 8)).round());
	} 
	if (typeof value != "bigint") throw new Error("Value must be a number or BigInt");
	global.data.economyTX.push({
		affectedID: id,
		operation: "set",
		value: value,
		reason: reason,
		oldbalance: global.data.economy[id],
		newbalance: value
	});
	global.data.economy[id] = value;
}

var safereset = function(id, reason) {
	validWallet(id);
	(typeof reason != "string") ? reason = "" : "";
	global.data.economyTX.push({
		affectedID: id,
		operation: "reset",
		value: BigInt(global.data.economyStart),
		reason: reason,
		oldbalance: global.data.economy[id],
		newbalance: BigInt(global.data.economyStart)
	});
	global.data.economy[id] = BigInt(global.data.economyStart);
}

var transferfunc = function (type, data) {
	var args = data.args;
	var id = getID(data.msgdata, type);
	if (args.length > 2 && sizeObject(data.mentions) > 0) {
		var value = Math.abs(parseValue(id, args[1]));
		if (!validBalance(id, value * sizeObject(data.mentions))) {
			return {
				handler: "internal",
				data: getLang("nmoney", data.resolvedLang)
			}
		} else {
			var txcode = random(100000000, 999999999);
			var rtdata = "";
			safesubtract(id, value * sizeObject(data.mentions), "Transfer code " + txcode);
			for (var y in data.mentions) {
				safeadd(y, value, "Transfer code " + txcode);
				rtdata != "" ? rtdata += "\n" : "";
				rtdata += getLang("transfered", data.resolvedLang).replace("{0}", value.floor(2)).replace("{1}", getSymbol()).replace("{2}", y);
			}
			return {
				handler: "internal",
				data: rtdata
			}
		}
	} else {
		return {
			handler: "internal",
			data: getLang("uargs", data.resolvedLang)
		}
	}
}

var unsafetransferfunc = function (type, data) {
	var args = data.args;
	var id = getID(data.msgdata, type);
	if (args.length > 2) {
		var value = Math.abs(parseValue(id, args[1]));
		if (!validBalance(id, value)) {
			return {
				handler: "internal",
				data: getLang("nmoney", data.resolvedLang)
			}
		} else {
			var y = args[2];
			var txcode = random(100000000, 999999999);
			safesubtract(id, value, "Transfer code " + txcode);
			safeadd(y, value, "Transfer code " + txcode);
			return {
				handler: "internal",
				data: getLang("transfered", data.resolvedLang).replace("{0}", value.floor(2)).replace("{1}", getSymbol()).replace("{2}", y)
			}
		}
	} else {
		return {
			handler: "internal",
			data: getLang("uargs", data.resolvedLang)
		}
	}
}

var getunsafewalletcode = function (type, data) {
	var id = getID(data.msgdata, type);
	validWallet(id);
	return {
		handler: "internal",
		data: getLang("wcode", data.resolvedLang).replace("{0}", id)
	}
}

var getbalance = function (id, getBigInt) {
	validWallet(id);
	if (getBigInt) {
		return global.data.economy[id];
	} else {
		return Number(global.data.economy[id]) / (10 ** 8);
	}
}

var getID = function (msgdata, type) {
	var id = "0";
	switch (type) {
		case "Facebook":
			id = "FB-" + msgdata.senderID;
			break;
		case "Discord":
			id = "DC-" + msgdata.author.id;
			break;
	}
	validWallet(id);
	return id;
}

var getSymbol = function() {
	return "Ƀ";
}

var validWallet = function (id) {
	if (typeof global.data.economy[id] != "bigint") {
		global.data.economy[id] = global.data.economyStart;
	}
}

var parseValue = function (id, value, returnBigInt) {
	validWallet(id);
	switch (typeof value) {
		case "string":
			switch (value) {
				case "all":
					return parseValue(id, getbalance(id, true));
				case "half":
					return parseValue(id, getbalance(id, true) / 2n);
				case "quarter":
					return parseValue(id, getbalance(id, true) / 4n);
				default:
					if (value.endsWith("%")) {
						var percentage = parseFloat(value.substr(0, value.length - 1));
						if (isNaN(percentage)) {
							if (returnBigInt) {
								return 0n;
							}
							return 0;
						} else {
							return parseValue(id, getbalance(id, true) / 10000n * BigInt((percentage * 100).round()));
						}
					} else {
						return parseValue(id, parseFloat(value));
					}
			}
		case "number": 
			if (isNaN(value)) {
				if (returnBigInt) {
					return 0n;
				}
				return 0;
			} else {
				if (returnBigInt) {
					return BigInt((value * (10 ** 8)).round());
				}
				return value;
			}
		case "bigint":
			if (returnBigInt) {
				return value;
			}
			return Number(value) / (10 ** 8);
		default:
			if (returnBigInt) {
				return 0n;
			}
			return 0;
	}
}

var validBalance = function (id, value) {
	validWallet(id);
	return (getbalance(id, true) - parseValue(id, value, true)) >= 0n;
}

module.exports = {
	balfunc: balfunc,
	baltopfunc: baltopfunc,
	transferfunc: transferfunc,
	unsafetransferfunc: unsafetransferfunc,
	getunsafewalletcode: getunsafewalletcode,
	operator: {
		add: safeadd,
		subtract: safesubtract,
		multiply: safemultiply,
		divide: safedivide,
		set: safeset,
		reset: safereset,
		get: getbalance
	},
	getID: getID,
	getSymbol: getSymbol,
	getBalance: getbalance,
	validBalance: validBalance,
	parseValue: parseValue,
	validWallet: validWallet
}
var log = console.log;
function onLoad(data) {
	log = data.log;
}

var fs = require("fs");
var path = require("path");
const worker = require('worker_threads');
var Worker = worker.Worker;
var os = require("os");
var http = require("http");
var streamBuffers = global.nodemodule["stream-buffers"];
var fetch = global.nodemodule["node-fetch"];
var wait = global.nodemodule["wait-for-stuff"];
var AdmZip = global.nodemodule["adm-zip"];
var Jimp = global.nodemodule["jimp"];

var workerPool = [];
var busy = [];
var messagePool = [];
var waiting = {};

(typeof global.data.toggleThanos != "object" || Array.isArray(global.data.toggleThanos)) ? global.data.toggleThanos = {} : "";
(typeof global.data.thanosMessageData != "object" || Array.isArray(global.data.thanosMessageData)) ? global.data.thanosMessageData = {} : "";

/**
 * Ensure <path> exists.
 *
 * @param   {string}  path  Path
 * @param   {number}  mask  Folder's mask
 *
 * @return  {object}        Error or nothing.
 */
function ensureExists(path, mask) {
  if (typeof mask != 'number') {
    mask = 0o777;
  }
  try {
    fs.mkdirSync(path, {
      mode: mask,
      recursive: true
    });
    return undefined;
  } catch (ex) {
    return { err: ex };
  }
}

var rootDir = path.join(__dirname, "..", "ThanosTimeStone");
ensureExists(rootDir);
ensureExists(path.join(rootDir, "deleted_msg"));
if (!fs.existsSync(path.join(rootDir, "config.json"))) {
	fs.writeFileSync(path.join(rootDir, "config.json"), JSON.stringify({
		useLink: true,
		disableAll: false,
		enableDefault: true,
		useSmallModel: false
	}), null, 4);
}
var config = JSON.parse(fs.readFileSync(path.join(rootDir, "config.json")));

var lang = (function () {
	if (global.fileMap[`Thanos_Lang_${global.config.language}`]) {
		return JSON.parse(global.fileMap[`Thanos_Lang_${global.config.language}`].toString());
	} else {
		return JSON.parse(global.fileMap[`Thanos_Lang_en_US`].toString());
	}
})();

if (!config.useLink) {
	var modelzip = new AdmZip(global.fileMap["Thanos_Model"]);
	var MODEL_SERVER = http.createServer((req, res) => {
		var file = modelzip.readFile(path.resolve("/", req.url).substr(1));
		if (file) {
			res.writeHead(200, {
				'Content-Type': 'text/plain'
			});
			res.write(file);
			res.end();
        } else {
            res.writeHead(404, {
                'Content-Type': 'text/plain'
            });
            res.write(`404 Not Found\r\nThanos Time Stone (Anti-Unsend) / C3CBot HTTP Model Server\r\n2019-2020 (C) UIRI`);
            res.end();
        }
    }).listen(0, "127.0.0.1");
	wait.for.event(MODEL_SERVER, "listening");
	var modelport = MODEL_SERVER.address().port;
	
	var wJS = global.fileMap["thanos_wjs"].toString();
	var workerCount = os.cpus().length;
	for (n = 0; n < workerCount; n++) {
		var w = new Worker(wJS, {
			eval: true,
			workerData: {
				small: !!config.useSmallModel,
				i: workerPool.length,
				dirname: __dirname,
				port: modelport
			}
		});
		busy.push(true);
		w.on("message", function (msg) {
			busy[msg.i] = msg.busy;
			log(`Worker ID ${msg.i} is ${msg.busy ? "now busy." : "no longer busy."}`);
			if (msg.resolve) {
				if (waiting[msg.msgID]) {
					waiting[msg.msgID](msg.data);
					delete waiting[msg.msgID];
					log(`Worker ID ${msg.i} return result for work ID ${msg.msgID}: ${msg.data[0].className} ${(msg.data[0].probability * 100).toFixed(2)}%`);
				}
			}
		});
		workerPool.push(w);
	}
	var clock = setInterval(function () {
		if (messagePool.length > 0) {
			var freeWorkerID = -1;
			for (var i in busy) {
				if (!busy[i]) {
					freeWorkerID = i;
					break;
				}
			}
			if (freeWorkerID != -1) {
				var d = messagePool.shift();
				workerPool[freeWorkerID].postMessage(d);
				log(`Given work ID ${d.id} to worker ID ${freeWorkerID}`);
			}
		}
	}, 250);
}

var chathook = function (type, data) {
	var message = data.msgdata;
	typeof global.data.toggleThanos[message.threadID] != "boolean" ? global.data.toggleThanos[message.threadID] = config.enableDefault : "";
	switch (message.type) {
		case "message": 
		case "message_reply":
			global.data.thanosMessageData[message.messageID] = message;
			for (var n in global.data.thanosMessageData) {
				if (Date.now() - global.data.thanosMessageData[n].timestamp >= 600000) {
					delete global.data.thanosMessageData[n];
				}
			}
			break;
		case "message_unsend":
			if (global.data.thanosMessageData[message.messageID]) {
				fs.writeFileSync(path.join(rootDir, "deleted_msg", message.messageID), JSON.stringify(global.data.thanosMessageData[message.messageID], null, 4));
			}
			if (global.data.thanosMessageData[message.messageID] && 
				!config.disableAll && 
				global.data.toggleThanos[message.threadID] &&
				message.senderID != data.facebookapi.getCurrentUserID()
			) {
				data.log("Running Anti-Unsend code...");
				var dmsg = global.data.thanosMessageData[message.messageID];
				if (config.useLink) {
					var pList = [];
					dmsg.attachments.forEach(v => {
						pList.push(global.plugins.shortener.shortURL(v.url));
					});
					Promise.all(pList).then(att => {
						att = att.map(x => x.url);
						var xz = `@${global.data.cacheName["FB-" + dmsg.senderID]}`
						var zx = "";
						if (att.length) {
							zx += "\r\n\r\nAttachments:";
							att.forEach(v => {
								zx += `\r\n${v}`;
							});
							zx += "\r\n";
						}
						var msg = lang.unsendHeader
							.replace("{0}", xz)
							.replace("{1}", zx)
							.replace("{2}", dmsg.body);
									
						data.facebookapi.sendMessage({
							body: `${data.prefix} ${msg}`,
							mentions: [{
								tag: xz,
								id: data.msgdata.senderID
							}]
						}, data.msgdata.threadID, function(){}, null, data.msgdata.isGroup);
					});
				} else {
					var parray = [];
					dmsg.attachments.forEach((a, n) => {
						parray.push(
							fetch(a.url)
								.then(res => (res.ok ? res.buffer() : ""))
								.then(function (buf) {
									if (buf != "") {
										var extension = (function (a) {
											switch (a.type) {
												case "photo":
												case "sticker": 
													return ".png";
												case "audio":
													return ".mp3";
												case "video":
													return ".mp4";
												case "animated_image":
													return ".gif";
												default:
													return "";
											}
										})(a);
										return {
											type: a.type,
											data: buf,
											name: a.filename + extension
										}
									} else {
										return null;
									}
								})
						);
					});
					Promise.all(parray)
						.then(att => {
							att = att.filter(x => !!x);
							data.log(`Downloaded all attachments (${att.length} to be exact).`);
							//attachmentArray = att;
							var promiseArr = [];
							att.forEach((x, n) => {
								if (x.type == "photo" || x.type == "animated_image") {
									promiseArr.push(new Promise((resolve, reject) => {
										Jimp.read(x.data)
											.then(function (z) {
												x.z = z;
												x.n = n;
												resolve(x);
											})
											.catch(reject);
									}));
								}
							});
							Promise.all(promiseArr)
								.then(rimage => {
									var promiseArr = [];
									rimage.forEach(x => {
										var n = x.n;
										var image = x.z;
										var bitmapObj = image.bitmap;
										messagePool.push({
											data: Array.from(new Uint8Array(bitmapObj.data)),
											width: bitmapObj.width,
											height: bitmapObj.height,
											id: `${message.messageID}-${n}`
										});
										promiseArr.push(new Promise(resolve => {
											waiting[`${message.messageID}-${n}`] = function (data) {
												resolve({
													buffer: x.data,
													data: data,
													name: x.name
												});
											};
										}));
									});
									return Promise.all(promiseArr);
								})
								.then(result => {
									var attx = [];
									var classifydata = "";
									for (var n in result) {
										if (result[n].data[0].className != "Porn" && result[n].data[0].className != "Hentai") {
											attx.push((function () {
												var z = new streamBuffers.ReadableStreamBuffer({
													frequency: 10,
													chunkSize: 2048
												});
												z.path = result[n].name;
												z.put(result[n].buffer);
												z.stop();
												return z;
											})());
										}
										classifydata == "" 
											? classifydata = `- ${result[n].data[0].className} (${(result[n].data[0].probability * 100).toFixed(2)}%)`
											: classifydata += `\r\n- ${result[n].data[0].className} (${(result[n].data[0].probability * 100).toFixed(2)}%)`;
									}
									var atty = att.filter(z => (z.type != "photo" && z.type != "animated_image"));
									var attz = atty.map(a => {
										var z = new streamBuffers.ReadableStreamBuffer({
											frequency: 10,
											chunkSize: 2048
										});
										z.path = a.name;
										z.put(a.data);
										z.stop();
										return z;
									});
									attx = attx.concat(attz);
									var xz = `@${global.data.cacheName["FB-" + data.msgdata.senderID]}`
									var msg = lang.unsendHeader
										.replace("{0}", xz)
										.replace("{1}", (classifydata != "" ? "\r\n\r\n" + lang["imgClassPercent"] + "\r\n" : "") + classifydata + (classifydata != "" ? "\r\n" : ""))
										.replace("{2}", dmsg.body);
									
									data.facebookapi.sendMessage({
										body: `${data.prefix} ${msg}`,
										attachment: attx,
										mentions: [{
											tag: xz,
											id: data.msgdata.senderID
										}]
									}, data.msgdata.threadID, function(){}, null, data.msgdata.isGroup);
								});
						});
				}
			}
	}
}

var toggle = async function (type, data) {
	if (data.msgdata.isGroup) {
		try {
			var adinfo = await data.facebookapi.getThreadInfo(data.msgdata.threadID);
			var adminIDs = adinfo.adminIDs.map(x => x.id.toString());
			if (adminIDs.indexOf(data.msgdata.senderID) == -1) {
				return {
					handler: "internal",
					data: lang["np"]
				}
			}
		} catch (ex) {
			return {
				handler: "internal",
				data: "Error while trying to get group admin info."
			}	
		}
	}
	var a = String(data.args[1]).toLocaleLowerCase();
	typeof global.data.toggleThanos[data.msgdata.threadID] != "boolean" ? global.data.toggleThanos[data.msgdata.threadID] = config.enableDefault : "";
	if (a == "on" || a == "off") {
		switch (a) {
			case "on":
				global.data.toggleThanos[data.msgdata.threadID] = true;
				break;
			case "off":
				global.data.toggleThanos[data.msgdata.threadID] = false;
				break;
		}
	}
	return {
		handler: "internal",
		data: `Thanos Time Stone: ${global.data.toggleThanos[data.msgdata.threadID] ? lang["on"] : lang["off"]}`
	}
}

var atoggle = function (type, data) {
	if (!data.admin) {
		return {
			handler: "internal",
			data: lang["np"]
		}
	}
	var a = String(data.args[1]).toLocaleLowerCase();
	if (a == "on" || a == "off") {
		switch (a) {
			case "on":
				config.disableAll = false;
				break;
			case "off":
				config.disableAll = true;
				break;
		}
		fs.writeFileSync(path.join(rootDir, "config.json"), JSON.stringify(config, null, 4));
	}
	return {
		handler: "internal",
		data: `Thanos Time Stone for *: ${!config.disableAll ? lang["on"] : lang["off"]}`
	}
}

module.exports = {
	chathook: chathook,
	onUnload: function () {
		for (var n in workerPool) {
			workerPool[n].terminate();
		}
		if (clock) {
			clearInterval(clock);
		}
		if (MODEL_SERVER) {
			MODEL_SERVER.close();
		}
	},
	onLoad: onLoad,
	toggle: toggle,
	atoggle: atoggle,
	waiting: waiting
}

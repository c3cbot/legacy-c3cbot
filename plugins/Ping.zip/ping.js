var pingtime = {};

var ping = function (type, data) {
	switch (type) {
		case "Facebook":
			var SC = data.time - data.msgdata.timestamp;
			typeof pingtime[data.msgdata.threadID] != "object" ? pingtime[data.msgdata.threadID] = {} : "";
			pingtime[data.msgdata.threadID].sc = SC;
			var etime = Date.now();
			pingtime[data.msgdata.threadID].etime = etime;
			data.facebookapi.sendMessage("\u200F\u200F\u200F\u200FPINGING\u200F\u200F\u200F\u200F", data.msgdata.threadID, function (err) {
				if (err) {
					return data.return({
						handler: "internal",
						data: `Facebook => Bot: ${SC}ms\nBot => Facebook: ERR!\nRound trip: ERR!`
					});
				}
				var stime = Date.now();
				var CS = stime - etime;
				pingtime[data.msgdata.threadID].cs = CS;
			}, null, data.msgdata.isGroup);
	}
}

var chathook = function (type, data) {
	switch (type) {
		case "Facebook":
			switch (data.msgdata.type) {
				case "message":
					if (data.msgdata.body.startsWith("\u200F\u200F\u200F\u200FPINGING\u200F\u200F\u200F\u200F")) {
						var rectime = Date.now();
						data.return({
							handler: "internal",
							data: `Facebook => Bot: ${pingtime[data.msgdata.threadID].sc}ms\nBot => Facebook: ${pingtime[data.msgdata.threadID].cs}ms\nRound trip: ${rectime - pingtime[data.msgdata.threadID].etime} (expected: ${pingtime[data.msgdata.threadID].sc + pingtime[data.msgdata.threadID].cs}ms)`
						});
					}
			}
	}
}

module.exports = {
	ping: ping,
	chathook: chathook
}
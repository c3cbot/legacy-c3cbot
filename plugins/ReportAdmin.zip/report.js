var r = function (type, data) {
	var msg = "";
	switch (type) {
		case "Facebook": 
			msg = data.msgdata.body.substr(data.args[0].length + 1);
			break;
		case "Discord":
			msg = data.msgdata.content.substr(data.args[0].length + 1);
			break;
		default: 
			return {
				handler: "internal",
				data: "Unsupported interface."
			}
	}
	if (msg == "") 
		return {
			handler: "internal",
			data: "No message."
		}
		
	var ts = Date.now();
	global.config.admins.forEach((v, i) => {
		switch (v.substr(0, 2)) {
			case "FB": 
				setTimeout(function () {
					if (data.facebookapi && data.facebookapi.sendMessage) {
						var obj = {};
						switch (type) {
							case "Facebook":
								obj = {
									body: `${data.prefix} @${global.data.cacheName["FB-" + data.msgdata.senderID]} (https://fb.com/${data.msgdata.senderID}) reported at ${data.msgdata.isGroup ? data.msgdata.threadID : "DM"}: \r\n${msg}`,
									mentions: [{
										tag: `@${global.data.cacheName["FB-" + data.msgdata.senderID]}`,
										id: data.msgdata.senderID
									}]
								}
								break;
							case "Discord":
								obj = {
									body: `${data.prefix} ${global.data.cacheName["DC-" + data.msgdata.author.id]} (Discord) reported at ${data.msgdata.channel.type == "dm" ? "DM" : data.msgdata.guild.name + " (" + data.msgdata.guild.id + ")"}: \r\n${msg}`
								}
						}
						data.facebookapi.sendMessage(obj, v.substr(3), function(){}, null, v.substr(3).length == 16);
					}
				}, i * 2000);
			case "DC":
				setTimeout(function () {
					if (data.discordapi) {
						var eobj = {};
						switch (type) {
							case "Facebook":
								eobj.title = "ReportAdmin";
								eobj.description = msg;
								eobj.color = 0x3b5998;
								eobj.timestamp = ts;
								eobj.footer = {
									text: `From: Facebook (${data.msgdata.isGroup ? "Group ID " + data.msgdata.threadID : "DM"})`
								};
								eobj.author = {
									name: global.data.cacheName["FB-" + data.msgdata.author.id],
									url: `https://facebook.com/profile.php?id=${data.msgdata.senderID}`,
									icon_url: "https://upload.wikimedia.org/wikipedia/commons/0/05/Facebook_Logo_%282019%29.png"
								};
								break;
							case "Discord":
								eobj.title = "ReportAdmin";
								eobj.description = msg;
								eobj.color = 0x7289da;
								eobj.timestamp = ts;
								eobj.footer = {
									text: `From: Discord (${data.msgdata.channel.type == "dm" ? "DM" : data.msgdata.guild.name + " - " + data.msgdata.guild.id})`
								};
								eobj.author = {
									name: global.data.cacheName["DC-" + data.msgdata.author.id],
									icon_url: data.msgdata.author.avatarURL()
								};
								break;
						}
						data.discordapi.users.fetch(v.substr(3)).then(u => {
							u.send("", {
								embed: eobj
							});
						});
					}
				}, i * 2000);
		}
		if (i == global.config.admins.length - 1) {
			data.return({
				handler: "internal",
				data: "Done."
			});
		}
	});
}

var gr = function (type, data) {
	var msg = "";
	switch (type) {
		case "Facebook": 
			msg = data.msgdata.body.substr(data.args[0].length + 1);
			break;
		case "Discord":
			msg = data.msgdata.content.substr(data.args[0].length + 1);
			break;
		default: 
			return {
				handler: "internal",
				data: "Unsupported interface."
			}
	}
	if (msg == "") 
		return {
			handler: "internal",
			data: "No message."
		}
		
	return {
		handler: "internal",
		data: "ERROR: GReport is not ready yet. Please come back later."
	}
}

module.exports = {
	r: r,
	gr: gr
}
var chathook = function chathook(type, data) {
	if (type != "Discord") return false;
	var args = data.msgdata.content
		.replace((/”/g), "\"")
		.replace((/“/g), "\"")
		.split(/((?:"[^"\\]*(?:\\[\S\s][^"\\]*)*"|'[^'\\]*(?:\\[\S\s][^'\\]*)*'|\/[^/\\]*(?:\\[\S\s][^/\\]*)*\/[gimy]*(?=\s|$)|(?:\\\s|\S))+)(?=\s|$)/)
		.filter(el => !(el == null || el == "" || el == " "))
		.map(xy => xy.replace(/"/g, ""));	
	
	if (!data.msgdata.content.startsWith(global.config.commandPrefix + "!") || args.length <= 1) return false;
	
	data.msgdata.delete({
		reason: "Creating embed message"
	}).then(() => {
		data.msgdata.channel.send("", {
			embed: {
				description: data.msgdata.content.slice((global.config.commandPrefix + "! ").length),
				timestamp: Date.now(),
				color: 0,
				footer: {
					text: `${global.config.commandPrefix}! <content>`
				},
				author: {
					name: data.msgdata.author.tag,
					icon_url: data.msgdata.author.avatarURL()
				}
			}
		});
	});
	return true;
}

module.exports = {
	chathook: chathook
}